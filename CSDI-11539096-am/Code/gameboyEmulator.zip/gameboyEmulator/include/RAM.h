#pragma once

#include <common.h>

u8 hram_read(u16 addr); // read a byte from the high RAM (HRAM)
void hram_write(u16 addr, u8 value); // write a byte to the high

u8 wram_read(u16 addr); // read a byte from the working RAM (WRAM)
void wram_write(u16 addr, u8 value); // write a byte to the working
