#pragma once

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;

#define BIT(a, n) ((a & (1 << n)) ? 1 : 0)

// #define BIT_SET(a, n, on) (on ? a |= (1 << n) : a &= ~(1 << n))
#define BIT_SET(a, n, on) {if (on) a |= (1 << n); else a &= ~(1 << n);}

// macro for checking if a value is between two other values
#define BETWEEN(a, b, c) ((a >= b && a <= c) ? true : false) 

u32 get_ticks();
void delay(u32 ms); // delay function

#define NO_IMPLEMENTATION {fprintf(stderr, "NOT DONE\n"); exit(-5); }