#pragma once

#include <common.h>

void stack_push(u8 value); // Push a value onto the stack
void stack_push16(u16 value); // Push a 16-bit value onto the stack

u8 stack_pop(); // Pop a value from the stack
u16 stack_pop16(); // Pop a 16-bit value from the stack
