#pragma once
// #pragma once

#include <common.h>

typedef struct {
    bool paused;
    bool running;
    bool die;   // emulator is dead
    u64 ticks;  // timer ticks
} emu_context;

int emu_run(int argc, char **argv);

emu_context *emu_get_context(); // Get the context of the emulator

// Emulator cycle
void emu_cycle(int cpu_cycle);
