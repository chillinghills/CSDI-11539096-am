#pragma once

#include <common.h>
#include <instructions.h>

enum {
    CPU_FLAGBIT_Z = 7,  /* Zero */
    CPU_FLAGBIT_N = 6,  /* Subtract (BCD) */
    CPU_FLAGBIT_H = 5,  /* Half-carry (BCD) */
    CPU_FLAGBIT_C = 4   /* Carry */
};

// CPU flags - these are used to check the status of the CPU
#define CPU_FLAG_Z BIT(ctx->regis.f, CPU_FLAGBIT_Z) // Zero flag
#define CPU_FLAG_N BIT(ctx->regis.f, CPU_FLAGBIT_N) // Subtraction flag (BCD)
#define CPU_FLAG_H BIT(ctx->regis.f, CPU_FLAGBIT_H) // Half carry flag (BCD)
#define CPU_FLAG_C BIT(ctx->regis.f, CPU_FLAGBIT_C) // Carry flag

typedef struct {
    // 8-bit CPU registers
    u8 a, f;  // Accumulator
    u8 b, c;  // General purpose registers
    u8 d, e;  // General purpose registers
    u8 h, l;  // High and low registers for memory access

    // 16-bit CPU registers
    u16 pc;   // Program Counter
    u16 sp;   // Stack Pointer
} cpu_registers;

typedef struct {
    cpu_registers regis;

    //current fetch...
    u16 fetch_data;
    u16 mem_dest;
    bool flg_mem_dest; // Flag to indicate if memory destination is set
    // bool dest_is_mem;
    u8 current_opcode;
    // Current instruction being executed
    instruction *current_inst;

    // CPU state
    bool halted; // CPU halted state
    bool stepping; // CPU stepping state

    // Interrupt master enable flag
    bool int_master_enabled;
    bool is_iME; // Interrupt Master Enable flag
    u8 ie_regis;  // Interrupt Enable Register
    u8 int_flags;
    
} cpu_context;

cpu_registers *cpu_get_regis();

void cpu_init();
bool cpu_step();

typedef void (*IN_PROC)(cpu_context *);

IN_PROC inst_get_processor(in_type type);

// Read and write CPU registers
u16 cpu_read_regis(reg_type reg_t);
void cpu_set_regis(reg_type reg_t, u16 value);

u8 cpu_get_ie_regis();
void cpu_set_ie_regis(u8 value);

u8 cpu_read_regis8(reg_type reg_t);
void cpu_set_regis8(reg_type reg_t, u8 value);

u8 cpu_get_int_flags();
void cpu_set_int_flags(u8 value);

void inst_to_str(cpu_context *ctx, char *str);
