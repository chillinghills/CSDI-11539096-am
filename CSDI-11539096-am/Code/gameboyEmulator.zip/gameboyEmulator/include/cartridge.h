#pragma once

#include <common.h>

typedef struct {
    char title[16]; // Title of the cartridge
    
    // Basic header information
    u8 entry[4]; // Entry point for the cartridge
    u8 version; // Version number
    u8 logo[0x30]; // Logo of the cartridge
    u8 type; // Type of the cartridge
    u8 sgb_flag; // SGB compatibility flag
    u8 cartridge_type; // type Cartridge type
    
    // ROM and RAM sizes
    u8 rom_size; // ROM size
    u8 ram_size; // RAM size
    
    // Code (Licensee) information
    u8 destination_code; // dest_code Destination code (0x00 for Japan, 0x01 for non-Japan)
    u8 lic_code; // lic_code Old licensee code
    u16 new_licensee_code; // new_lic_code New licensee code
    
    // Checksum - used for verification
    u8 header_checksum; // checksum Header checksum
    u16 global_checksum; // Global checksum    
} rom_header;
 
bool cart_load(char *cart); // Load the cartridge from a file
u8 cart_read(u16 addr); // read a byte from the address bus
void cart_write(u16 addr, u8 value);

bool cart_save(); // Save the cartridge to a file
void cart_battery_backed_ram_load();
void cart_battery_backed_ram_save();