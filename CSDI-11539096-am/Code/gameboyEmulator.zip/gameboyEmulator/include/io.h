#pragma once

#include <common.h>

// I/O functions
u8 io_read(u16 address);
void io_write(u16 address, u8 value);
