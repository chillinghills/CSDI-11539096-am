#pragma once

#include <common.h>

typedef struct {
    u16 div; // Divider register
    u8 tima; // Timer A counter
    
    u8 tma;  // Timer A modulo
    u8 tac;  // Timer A control
} timer_context;

void timer_init(); // initialize the timer
void timer_tick(); // tick the timer

// Timer register functions
void timer_write(u16 address, u8 value);
u8 timer_read(u16 address);

// Get the context of the timer
timer_context *timer_get_context();
