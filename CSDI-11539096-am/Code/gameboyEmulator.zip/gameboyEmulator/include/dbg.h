#pragma once

#include <common.h>
#include <cpu.h>

// Debugging functions
void dbg_update();
void dbg_print();
