#pragma once

#include <common.h>

// 4 PPU modes: HBlank, VBlank, OAM, and Transfer
void ppu_mode_hblank();
void ppu_mode_vblank();
void ppu_mode_oam();
void ppu_mode_xfer();

