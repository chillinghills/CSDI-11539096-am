// LCD Screen for Game Boy

#pragma once

#include <common.h>

typedef struct {
    // Registers
    u8 lcdc; // LCD Control Register
    u8 lcds; // LCD Status Register
    u8 scroll_x;    u8 scroll_y;

    // LCD
    u8 ly;
    u8 ly_compare;

    // DMA
    u8 dma;
    u8 bg_palette;
    u8 obj_palette[2];

    // Window position
    u8 win_x;       u8 win_y;

    u32 sp1_colors[4]; // Sprite 1 colors
    u32 sp2_colors[4]; // Sprite 2 colors
    u32 bg_colors[4];  // Background colors

} lcd_context; // LCD context

typedef enum {
    MODE_HBLANK,
    MODE_VBLANK,
    MODE_OAM,
    MODE_XFER
} lcd_mode; // 4 LCD mode: including HBLANK, VBLANK, OAM, and XFER

// Get the current LCD context
lcd_context *lcd_get_context();

enum {
    LCDC_BIT_BGW_ENABLE   = 0, /* BG/Window enable */
    LCDC_BIT_OBJ_ENABLE   = 1, /* OBJ enable       */
    LCDC_BIT_OBJ_HEIGHT   = 2, /* OBJ size (0:8,1:16) */
    LCDC_BIT_BG_MAP_AREA  = 3, /* BG map area sel  */
    LCDC_BIT_BGW_DATA_SEL = 4, /* BG/Win data area */
    LCDC_BIT_WIN_ENABLE   = 5, /* Window enable    */
    LCDC_BIT_WIN_MAP_AREA = 6, /* Window map area  */
    LCDC_BIT_LCD_ENABLE   = 7  /* LCD on/off       */
};

//// LCD
// Background Window
#define LCDC_BGW_ENABLE (BIT(lcd_get_context()->lcdc, LCDC_BIT_BGW_ENABLE))
#define LCDC_BG_MAP_AREA (BIT(lcd_get_context()->lcdc, LCDC_BIT_BG_MAP_AREA) ? 0x9C00 : 0x9800)
#define LCDC_BGW_DATA_AREA (BIT(lcd_get_context()->lcdc, LCDC_BIT_BGW_DATA_SEL) ? 0x8000 : 0x8800)
// Detail object in Window
#define LCDC_OBJ_ENABLE (BIT(lcd_get_context()->lcdc, LCDC_BIT_OBJ_ENABLE))
#define LCDC_OBJ_HEIGHT (BIT(lcd_get_context()->lcdc, LCDC_BIT_OBJ_HEIGHT) ? 16 : 8)
// Detail Window
#define LCDC_WIN_ENABLE (BIT(lcd_get_context()->lcdc, LCDC_BIT_WIN_ENABLE))
#define LCDC_WIN_MAP_AREA (BIT(lcd_get_context()->lcdc, LCDC_BIT_WIN_MAP_AREA) ? 0x9C00 : 0x9800)
#define LCDC_LCD_ENABLE (BIT(lcd_get_context()->lcdc, LCDC_BIT_LCD_ENABLE))

typedef enum {
    SS_HBLANK = (1 << 3),
    SS_VBLANK = (1 << 4),
    SS_OAM = (1 << 5),
    SS_LYC = (1 << 6),
} stat_src; // Stat source

// Status
#define LCDS_STAT_INT(src) (lcd_get_context()->lcds & src)
#define LCDS_MODE ((lcd_mode)(lcd_get_context()->lcds & 0b11))
#define LCDS_MODE_SET(mode) { lcd_get_context()->lcds &= ~0b11; lcd_get_context()->lcds |= mode; }
#define LCDS_LYC (BIT(lcd_get_context()->lcds, 2))
#define LCDS_LYC_SET(b) (BIT_SET(lcd_get_context()->lcds, 2, b))

// LCD
void lcd_init();
// get LCD
u8 lcd_read(u16 address);
void lcd_write(u16 address, u8 value);
