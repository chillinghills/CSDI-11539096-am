#pragma once

#include <common.h>

// CPU - 8 bits; Address Bus - 16 bits;

u8 bus_read(u16 addr); // read a byte from the address bus
u16 bus_read16(u16 addr); // read a 16-bit value from the address bus

void bus_write(u16 addr, u8 value); // write a byte to the address bus
void bus_write16(u16 addr, u16 value); // write a 16-bit value to the address bus
