
#pragma once

#include <cpu.h>

typedef enum {
    IT_VBLANK   = 1 << 0,    // Vertical Blank
    IT_LCD_STAT = 1 << 1,    // LCD Status
    IT_TIMER    = 1 << 2,    // Timer
    IT_SERIAL   = 1 << 3,    // Serial
    IT_JOYPAD   = 1 << 4     // Joypad
} interrupt_type; // Interrupt types

// Interrupt request
void cpu_request_interrupt(interrupt_type t);
// Interrupt handling
void cpu_handle_interrupts(cpu_context *ctx);
