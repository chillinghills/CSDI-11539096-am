#pragma once

#include <common.h>

// UI constants
// Reference: https://gbdev.io/pandocs/
static const int SCREEN_WIDTH = 1024;
static const int SCREEN_HEIGHT = 768;

// UI function prototypes
void ui_init();
void ui_handle_events();
void ui_update();
