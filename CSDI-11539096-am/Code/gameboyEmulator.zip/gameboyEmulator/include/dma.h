#pragma once

#include <common.h>

// DMA functions
void dma_start(u8 start);
void dma_tick(); // Update the DMA transfer

bool dma_transferring(); // Check if DMA is currently transferring