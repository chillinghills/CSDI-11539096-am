// Random Access Memory (RAM)
// #include <string.h>
#include <ram.h>

#define WRAM_BASE 0xC000
#define WRAM_SIZE 0x2000    // 8 KiB: 0xC000 - 0xDFFF
#define HRAM_BASE 0xFF80
#define HRAM_SIZE 0x80      // 128 B: 0xFF80 - 0xFFFF

typedef struct {
    // Working RAM and High RAM
    u8 wram[WRAM_SIZE];
    u8 hram[HRAM_SIZE];
} ram_context; // RAM context structure

static ram_context ctx;

//// -----WRAM-----

// Working RAM read function
u8 wram_read(u16 addr) {
    addr -= WRAM_BASE; // Adjust address to WRAM range
    if (addr >= WRAM_SIZE) {
        printf("INVALID WRAM ADDRESS: %08X\n", addr + WRAM_BASE);
        exit(-1);
    }

    // Read the value from WRAM
    return ctx.wram[addr];
}
// Working RAM write function
void wram_write(u16 addr, u8 value) {
    addr -= WRAM_BASE; // Adjust address to WRAM range

    // // Check if the address is within the WRAM range
    // if (addr >= 0x2000) {
    //     printf("INVALID WRAM ADDRESS: %08X\n", addr + 0xC000);
    //     exit(-1);
    // }
    ctx.wram[addr] = value;
}


//// -----HRAM-----

// High RAM read function
u8 hram_read(u16 addr) {
    addr -= HRAM_BASE; // Adjust address to HRAM range

    // // Check if the address is within the HRAM range
    // if (addr >= HRAM_SIZE) {
    //     printf("INVALID HRAM ADDRESS: %08X\n", addr + HRAM_BASE);
    //     exit(-1);
    // }
    return ctx.hram[addr];
}
// High RAM write function
void hram_write(u16 addr, u8 value) {
    addr -= HRAM_BASE; // Adjust address to HRAM range

    // // Check if the address is within the HRAM range
    // if (addr >= HRAM_SIZE) {
    //     printf("INVALID HRAM ADDRESS: %08X\n", addr + HRAM_BASE);
    //     exit(-1);
    // }
    ctx.hram[addr] = value;
}
