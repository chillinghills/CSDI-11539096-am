#include <io.h>
#include <dma.h>
#include <lcd.h>
#include <cpu.h>
#include <timer.h>
#include <gamepad.h>

static char serial_data[2]; // Serial data buffer

// Read from I/O registers
u8 io_read(u16 addr) {
    if (addr == 0xFF00) {
        return gamepad_get_output();
    }

    if (addr == 0xFF01) {
        return serial_data[0];
    }

    if (addr == 0xFF02) {
        return serial_data[1];
    }

    // Timer registers
    if (BETWEEN(addr, 0xFF04, 0xFF07)) {
        return timer_read(addr);
    }

    // Interrupt flags
    if (addr == 0xFF0F) {
        return cpu_get_int_flags();
    }

    // Sound registers
    if (BETWEEN(addr, 0xFF10, 0xFF3F)) {
        return 0; // Sound registers got ignored
    }

    if (BETWEEN(addr, 0xFF40, 0xFF4B)) {
        return lcd_read(addr);
    }

    // Unsupported I/O register read
    printf("UNSUPPORTED read bus coding:(%04X)\n", addr);
    // return 0 as default
    return 0;
}

// Write to I/O registers
void io_write(u16 addr, u8 value) {
    if (addr == 0xFF00) {
        gamepad_set_sel(value);
        return;
    }
    
    if (addr == 0xFF01) {
        serial_data[0] = value;
        return;
    }

    if (addr == 0xFF02) {
        serial_data[1] = value;
        return;
    }

    // Timer registers
    if (BETWEEN(addr, 0xFF04, 0xFF07)) {
        timer_write(addr, value);
        return;
    }
    
    // Interrupt flags
    if (addr == 0xFF0F) {
        cpu_set_int_flags(value);
        return;
    }

    // Sound registers
    if (BETWEEN(addr, 0xFF10, 0xFF3F)) {
        return;  // Sound registers got ignored
    }

    if (BETWEEN(addr, 0xFF40, 0xFF4B)) {
        lcd_write(addr, value);
        return;
    }

    // Unsupported I/O register write
    printf("UNSUPPORTED write bus coding:(%04X)\n", addr);
}
