#include <ui.h>
#include <emu.h>
#include <bus.h>
#include <ppu.h>
#include <gamepad.h>

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>


// SDL variables
SDL_Window *sdlWindow;
SDL_Surface *screen;
SDL_Renderer *sdlRenderer;
SDL_Texture *sdlTexture;

// SDL Debug variables
SDL_Window *sdlDebugWindow;
SDL_Surface *debugScreen;
SDL_Renderer *sdlDebugRenderer;
SDL_Texture *sdlDebugTexture;


// SDL Debug variables
static int scale = 4; // Scale factor for debugging

void ui_init() {

    // Initialize SDL
    SDL_Init(SDL_INIT_VIDEO);
    printf("SDL INIT\n");
    TTF_Init();
    printf("TTF INIT\n");

    // Create SDL window and renderer
    SDL_CreateWindowAndRenderer(SCREEN_WIDTH, SCREEN_HEIGHT, 0, &sdlWindow, &sdlRenderer);
    screen = SDL_CreateRGBSurface(0, SCREEN_WIDTH, SCREEN_HEIGHT, 32,
                                            0x00FF0000,
                                            0x0000FF00,
                                            0x000000FF,
                                            0xFF000000);
    sdlTexture = SDL_CreateTexture(sdlRenderer,
                                                SDL_PIXELFORMAT_ARGB8888,
                                                SDL_TEXTUREACCESS_STREAMING,
                                                SCREEN_WIDTH, SCREEN_HEIGHT);
    SDL_CreateWindowAndRenderer(16 * 8 * scale, 32 * 8 * scale, 0, 
        &sdlDebugWindow, &sdlDebugRenderer);


    // Create debug screen surface
    debugScreen = SDL_CreateRGBSurface(0, (16 * 8 * scale) + (16 * scale), 
                                            (32 * 8 * scale) + (64 * scale), 32,
                                            0x00FF0000,
                                            0x0000FF00,
                                            0x000000FF,
                                            0xFF000000);
    sdlDebugTexture = SDL_CreateTexture(sdlDebugRenderer,
                                            SDL_PIXELFORMAT_ARGB8888,
                                            SDL_TEXTUREACCESS_STREAMING,
                                            (16 * 8 * scale) + (16 * scale), 
                                            (32 * 8 * scale) + (64 * scale));

    // Position the debug window
    int x, y;
    SDL_GetWindowPosition(sdlWindow, &x, &y);
    SDL_SetWindowPosition(sdlDebugWindow, x + SCREEN_WIDTH + 10, y);
}



// SDL Timing functions
u32 get_ticks() {
    return SDL_GetTicks(); // Get the current ticks
}
void delay(u32 ms) {
    SDL_Delay(ms);
}

// SDL Debug variables
static unsigned long tile_colors[4] = {0xFFFFFFFF, 0xFFAAAAAA, 0xFF555555, 0xFF000000}; 

// Display a tile on the given surface
void display_tile(SDL_Surface *surface, u16 initialPos, u16 tileNum, int x, int y) {
    SDL_Rect rc; // Rectangle for the tile

    for (int tileY = 0; tileY < 16; tileY += 2) {
        u8 b1 = bus_read(initialPos + (tileNum * 16) + tileY);
        u8 b2 = bus_read(initialPos + (tileNum * 16) + tileY + 1);

        // u8 pal = (b1 & 0x3) | ((b2 & 0x3) << 2);

        // Loop through each bit
        for (int bit = 7; bit >= 0; bit--) {
            u8 hi = !!(b1 & (1 << bit)) << 1;
            u8 lo = !!(b2 & (1 << bit));

            u8 color = hi | lo; // Combine high and low bits

            // Set the rectangle for the tile
            rc.y = y + (tileY / 2 * scale);
            rc.x = x + ((7 - bit) * scale); // Set the x position
            rc.h = scale; rc.w = scale;

            // Fill the rectangle with the appropriate color
            SDL_FillRect(surface, &rc, tile_colors[color]);
        }
    }
}


// Update the debug window
void update_dbg_window() {
    int xDraw = 0;
    int yDraw = 0;
    int tileNum = 0;

    SDL_Rect rc;
    rc.x = 0;    rc.y = 0;

    // Fill the background
    rc.w = debugScreen->w;
    rc.h = debugScreen->h;
    SDL_FillRect(debugScreen, &rc, 0xFF111111);

    // Draw the tiles
    u16 addr = 0x8000;

    // xDraw = 0;
    for (int y = 0; y < 24; y++) {
        for (int x = 0; x < 16; x++) {
            display_tile(debugScreen, addr, tileNum, xDraw + (x * scale), yDraw + (y * scale));
            xDraw += (8 * scale); // Move to the next tile position
            tileNum++;
        }

        // Reset the yDraw position
        yDraw += (8 * scale);
        xDraw = 0;
    }

    // Update the debug texture
    SDL_UpdateTexture(sdlDebugTexture, NULL, debugScreen->pixels, debugScreen->pitch);
    SDL_RenderClear(sdlDebugRenderer);
    SDL_RenderCopy(sdlDebugRenderer, sdlDebugTexture, NULL, NULL);
    SDL_RenderPresent(sdlDebugRenderer);
}


// Update the UI
void ui_update() {
    SDL_Rect rc;
    rc.x = rc.y = 0;
    rc.w = rc.h = 2048; // Set the width and height

    u32 *video_buffer = ppu_get_context()->video_buffer;

    // Draw the video buffer
    for (int line_num = 0; line_num < YRES; line_num++) {
        for (int x = 0; x < XRES; x++) {
            rc.x = x * scale;     rc.y = line_num * scale;
            rc.h = scale;         rc.w = scale;

            // Fill the rectangle with the appropriate color
            SDL_FillRect(screen, &rc, video_buffer[x + (line_num * XRES)]);
        }
    }

    // Update the texture
    SDL_UpdateTexture(sdlTexture, NULL, screen->pixels, screen->pitch);
    SDL_RenderClear(sdlRenderer);
    SDL_RenderCopy(sdlRenderer, sdlTexture, NULL, NULL);
    SDL_RenderPresent(sdlRenderer);

    // Update the debug window
    update_dbg_window();
}

void ui_on_key(bool down, u32 key_code) {
    // Update the gamepad state
    switch(key_code) {
        case SDLK_z: gamepad_get_state()->b = down; break;
        case SDLK_x: gamepad_get_state()->a = down; break;
        // case SDLK_c: gamepad_get_state()->x = down; break;
        // case SDLK_v: gamepad_get_state()->y = down; break;
        case SDLK_RETURN: gamepad_get_state()->start = down; break; // Start

        case SDLK_TAB: gamepad_get_state()->select = down; break;
        // D-Pad
        case SDLK_UP: gamepad_get_state()->up = down; break;
        case SDLK_DOWN: gamepad_get_state()->down = down; break;
        case SDLK_LEFT: gamepad_get_state()->left = down; break;
        case SDLK_RIGHT: gamepad_get_state()->right = down; break;
    }

}


// Handle events
void ui_handle_events() {
    SDL_Event e;
    while (SDL_PollEvent(&e) > 0)
    {
        // Key up events
        if (e.type == SDL_KEYUP) {
            ui_on_key(false, e.key.keysym.sym);
        }
        // Key down events
        if (e.type == SDL_KEYDOWN) {
            ui_on_key(true, e.key.keysym.sym);
        }
        // Close the emulator
        if (e.type == SDL_WINDOWEVENT && e.window.event == SDL_WINDOWEVENT_CLOSE) {
            emu_get_context()->die = true; // Close the emulator
        }
    }
}

