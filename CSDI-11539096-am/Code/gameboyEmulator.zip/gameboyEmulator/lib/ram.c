// #include <string.h>
#include <ram.h>

typedef struct {
    // Working RAM and High RAM
    u8 wram[0x2000];
    u8 hram[0x80];
} ram_context; // RAM context structure

static ram_context ctx;

//// -----WRAM-----

// Working RAM read function
u8 wram_read(u16 addr) {
    addr -= 0xC000; // Adjust address to WRAM range
    if (addr >= 0x2000) {
        printf("INVALID WRAM ADDRESS: %08X\n", addr + 0xC000);
        exit(-1);
    }

    // Read the value from WRAM
    return ctx.wram[addr];
}
// Working RAM write function
void wram_write(u16 addr, u8 value) {
    addr -= 0xC000; // Adjust address to WRAM range

    // // Check if the address is within the WRAM range
    // if (addr >= 0x2000) {
    //     printf("INVALID WRAM ADDRESS: %08X\n", addr + 0xC000);
    //     exit(-1);
    // }
    ctx.wram[addr] = value;
}


//// -----HRAM-----

// High RAM read function
u8 hram_read(u16 addr) {
    addr -= 0xFF80; // Adjust address to HRAM range

    // // Check if the address is within the HRAM range
    // if (addr >= 0x80) {
    //     printf("INVALID HRAM ADDRESS: %08X\n", addr + 0xFF80);
    //     exit(-1);
    // }
    return ctx.hram[addr];
}
// High RAM write function
void hram_write(u16 addr, u8 value) {
    addr -= 0xFF80; // Adjust address to HRAM range

    // // Check if the address is within the HRAM range
    // if (addr >= 0x80) {
    //     printf("INVALID HRAM ADDRESS: %08X\n", addr + 0xFF80);
    //     exit(-1);
    // }
    ctx.hram[addr] = value;
}
