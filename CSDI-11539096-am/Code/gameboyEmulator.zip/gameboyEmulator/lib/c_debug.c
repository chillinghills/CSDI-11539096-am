#include <c_debug.h>
#include <bus.h>

#define REG_SB 0xFF01   // Serial transfer data
#define REG_SC 0xFF02   // Serial transfer control
#define SC_TRIGGER 0x81 // When SC == 0x81, take SB as a debug char

static char dbg_msg[1024] = {0}; // Debug message buffer
static int msg_size = 0;

// Update the debug message
void dbg_update() {
    if (bus_read(REG_SC) == SC_TRIGGER) {
        char c = bus_read(REG_SB);

        dbg_msg[msg_size++] = c;

        bus_write(REG_SC, 0);
    }
}

void dbg_print() {
    if (dbg_msg[0]) {
        //printf("DBG: %s\n", dbg_msg);
    }
}
