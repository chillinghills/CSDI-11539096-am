#include <bus.h>
#include <cartridge.h>
#include <ram.h>
// #include <common.h>
#include <cpu.h>
#include <io.h>
#include <ppu.h>
#include <DMA.h>

// Memory map constants
#define ROM0_ROMX_START   0x0000
#define ROM0_ROMX_END     0x7FFF

#define VRAM_START        0x8000
#define VRAM_END          0x9FFF

#define EXTRAM_START      0xA000
#define EXTRAM_END        0xBFFF

#define WRAM_START        0xC000
#define WRAM_END          0xDFFF

#define ECHORAM_START     0xE000
#define ECHORAM_END       0xFDFF

#define OAM_START         0xFE00
#define OAM_END           0xFE9F

#define OAM_UNUSED_START  0xFEA0
#define OAM_UNUSED_END    0xFEFF

#define IO_START          0xFF00
#define IO_END            0xFF7F

#define HRAM_START        0xFF80
#define HRAM_END          0xFFFE

#define IE_ADDR           0xFFFF

// ---------- Memory Map ----------
u8 bus_read(u16 address) {
    if (address < VRAM_START) {
         // Read from ROM 
        return cart_read(address);
    } else if (address < EXTRAM_START) {
        // Read from VRAM
        return ppu_vram_read(address);
    } else if (address < WRAM_START) {
        // Read from Cartridge RAM
        return cart_read(address);
    } else if (address < ECHORAM_START) {
        // Read from WRAM (Working RAM)
        return wram_read(address);
    } else if (address < OAM_START) {
        // Read from reserved echo RAM
        return 0;
    } else if (address < OAM_UNUSED_START) {
        // Read from OAM
        if (dma_transferring()) {
            return 0xFF;
        } // If DMA is transferring, return 0xFF
        return ppu_oam_read(address);
    } else if (address < IO_START) {
        // Read from reserved OAM
        return 0;
    } else if (address < HRAM_START) {
        // Read from IO Registers
        return io_read(address);
    } else if (address == IE_ADDR) {
        // CPU ENABLE REGISTER
        return cpu_get_ie_regis();
    }
    // Read from HRAM (High RAM)
    return hram_read(address);
}


void bus_write(u16 address, u8 value) {
    if (address < VRAM_START) {
        // Write to ROM
        cart_write(address, value);
    } else if (address < EXTRAM_START) {
        // Write to VRAM
        ppu_vram_write(address, value);
    } else if (address < WRAM_START) {
        // Write to EXT-RAM
        cart_write(address, value);
    } else if (address < ECHORAM_START) {
        // Write to WRAM
        wram_write(address, value);
    } else if (address < OAM_START) {
        // Write to reserved echo RAM
    } else if (address < OAM_UNUSED_START) {
        // Write to OAM
        if (dma_transferring()) {
            return;
        }
        // Write to OAM
        ppu_oam_write(address, value);
    } else if (address < IO_START) {
        // Write to reserved OAM
        // Not implemented
    } else if (address < HRAM_START) {
        // Write to IO Registers
        io_write(address, value);
    } else if (address == IE_ADDR) {
        // Write to CPU SET ENABLE REGISTER
        cpu_set_ie_regis(value);
    } 
    
    else {
        // Write to HRAM (High RAM)
        hram_write(address, value);
    }
}


// Read 16 bits from the bus
u16 bus_read16(u16 address) {
    u16 lo = bus_read(address);
    u16 hi = bus_read(address + 1);

    return lo | (hi << 8); // Combine low and high bytes
    //     if (addr < 0x8000) {
//         return cart_read(addr); // Read from ROM 
//     }
//     printf("UNSUPPORTED bus read(%04X)\n", addr);
//     //NO_IMPLEMENTATION; // Not yet implemented for other address ranges
}

void bus_write16(u16 address, u16 value) {
    // u16 lo = value & 0xFF; // Low byte
    // u16 hi = (value >> 8) & 0xFF; // High byte

    // bus_write(addr + 1, hi); // Write high byte
    // bus_write(addr, lo); // Write low byte
//     if (addr < 0x8000) {
//         cart_write(addr, value); // Write to ROM 
//         return;
//     }
    bus_write(address + 1, (value >> 8) & 0xFF);
    bus_write(address, value & 0xFF);  // Write low byte first
}
