#include <cpu.h>

#include <emu.h>
#include <bus.h>

extern cpu_context ctx; // Global CPU context

#define IO_HIGH 0xFF00

void do_fetch_data() {
    ctx.mem_dest = 0; // Reset memory destination
    ctx.flg_mem_dest = false; // Reset fetched data

    if (ctx.current_inst == NULL) {
        // If the instruction is not valid, return
        // ctx.fetch_data = 0;
        // ctx.mem_dest = 0;
        // ctx.flg_mem_dest = 0;
        return;
    }

    switch(ctx.current_inst->mode) {
        case AM_IMP: // No operands
            return; // No data to fetch
            // ctx.fetch_data = 0; // No data to fetch
            // break;
        case AM_R: // Register
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_1);
            return;
        
        case AM_R_D8: // Immediate data
            ctx.fetch_data = bus_read(ctx.regis.pc);
            emu_cycle(1);
            ctx.regis.pc++;  // Increment program counter after fetching immediate data
            return;
        
        case AM_R_R: // Register to register
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_2);
            // ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_2);
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set
            return;

        case AM_R_D16:
        case AM_D16: { // 16-bit immediate data
            u16 lo = bus_read(ctx.regis.pc);
            emu_cycle(1);
            u16 hi = bus_read(ctx.regis.pc + 1);
            emu_cycle(1);

            ctx.fetch_data = lo | (hi << 8);// Combine high and low bytes
            // ctx.fetch_data = bus_read(ctx.regis.pc) | (bus_read(ctx.regis.pc + 1) << 8);
            // emu_cycle(2);
            ctx.regis.pc += 2; // Increment program counter after fetching 16-bit immediate data
            
            // printf("  operand = %04X\n", ctx.fetch_data);
            return;
        }

        case AM_MR_R: // Memory to register
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_2);
            ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            ctx.flg_mem_dest = true;

            if (ctx.current_inst->reg_1 == RT_C) {
                // If the first register is C, read from the IO port
                ctx.mem_dest |= 0xFF00; // IO port address
            }

            return;

        case AM_R_MR: { // Register to memory
            // ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set
            u16 tmp_addr = cpu_read_regis(ctx.current_inst->reg_2);

            if (ctx.current_inst->reg_2 == RT_C) {
                // If the second register is C, write to the IO port
                tmp_addr |= IO_HIGH; // IO port address
            }

            ctx.fetch_data = bus_read(tmp_addr);
            emu_cycle(1);

        } return;

        // Register AND (HL)
        case AM_R_HLI: // Register to (HL+)
            ctx.fetch_data = bus_read(cpu_read_regis(ctx.current_inst->reg_2));
            emu_cycle(1);
            cpu_set_regis(RT_HL, cpu_read_regis(RT_HL) + 1);
            return;

        case AM_R_HLD: // Register to (HL-)
            ctx.fetch_data = bus_read(cpu_read_regis(ctx.current_inst->reg_2));
            emu_cycle(1);
            cpu_set_regis(RT_HL, cpu_read_regis(RT_HL) - 1);
            return;

        case AM_HLI_R: // (HL+) to register
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_2);
            ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            // bus_write(cpu_read_regis(RT_HL), cpu_read_regis(ctx.current_inst->reg_1));
            // emu_cycle(1);
            ctx.flg_mem_dest = true; // Indicate that memory destination is set
            cpu_set_regis(RT_HL, cpu_read_regis(RT_HL) + 1);// Increment HL
            return;

        case AM_HLD_R: // (HL-) to register
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_2);
            ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            // bus_write(cpu_read_regis(RT_HL), cpu_read_regis(ctx.current_inst->reg_1));
            // emu_cycle(1);
            ctx.flg_mem_dest = true; // Indicate that memory destination is set
            cpu_set_regis(RT_HL, cpu_read_regis(RT_HL) - 1); // Decrement HL
            return;

        case AM_R_A8: // Register to absolute address
            ctx.fetch_data = bus_read(ctx.regis.pc);
            emu_cycle(1);
            ctx.regis.pc++; // Increment program counter after fetching absolute address
            // ctx.mem_dest = ctx.fetch_data | 0xFF00; // Absolute address in IO port space
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set

            return;

        case AM_A8_R:  // Absolute address to register
            ctx.mem_dest = bus_read(ctx.regis.pc) | IO_HIGH;
            ctx.flg_mem_dest = true;
            emu_cycle(1);
            ctx.regis.pc++; // Increment program counter after fetching absolute address
            // ctx.mem_dest = ctx.fetch_data | 0xFF00; // Absolute address in IO port space
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set
            return;

        case AM_HL_SPR:  // HL to SP relative
            ctx.fetch_data = bus_read(ctx.regis.pc);
            emu_cycle(1);
            ctx.regis.pc++;
            return;

        case AM_D8:  // 8-bit immediate data
            ctx.fetch_data = bus_read(ctx.regis.pc);
            emu_cycle(1);
            ctx.regis.pc++;
            return;

        case AM_A16_R: // 16-bit immediate data to register
        case AM_D16_R: { // 16-bit immediate data
            u16 lo = bus_read(ctx.regis.pc);
            emu_cycle(1);
            u16 hi = bus_read(ctx.regis.pc + 1);
            emu_cycle(1);
            // ctx.fetch_data = lo | (hi << 8); // Combine high and low bytes
            ctx.mem_dest = lo | (hi << 8);
            // emu_cycle(2);
            ctx.flg_mem_dest = true; // Indicate that memory destination is set
            ctx.regis.pc += 2; // Increment program counter after fetching 16-bit immediate data
            ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_2); // Fetch data from the second register
            // printf("  operand = %04X\n", ctx.fetch_data);

        } return;

        case AM_MR_D8:// Memory to 8-bit immediate data
            // ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set
            ctx.fetch_data = bus_read(ctx.regis.pc);
            emu_cycle(1);
            ctx.regis.pc++;
            ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            ctx.flg_mem_dest = true;
            return;

        case AM_MR: // Memory to register
            ctx.mem_dest = cpu_read_regis(ctx.current_inst->reg_1);
            ctx.flg_mem_dest = true; // Indicate that memory destination is set
            ctx.fetch_data = bus_read(cpu_read_regis(ctx.current_inst->reg_1));
            emu_cycle(1);
            return;

        case AM_R_A16: {// Register to 16-bit immediate data
            // ctx.fetch_data = cpu_read_regis(ctx.current_inst->reg_1);
            // ctx.mem_dest = bus_read(ctx.regis.pc) | (bus_read(ctx.regis.pc + 1) << 8);
            // ctx.fetch_data = bus_read(ctx.regis.pc) | (bus_read(ctx.regis.pc + 1) << 8);
            
            // emu_cycle(2);
            // ctx.flg_mem_dest = true; // Indicate that memory destination is set
            // ctx.regis.pc += 2; // Increment program counter after fetching 16-bit immediate data
            // return;
            u16 lo = bus_read(ctx.regis.pc); // Read low byte
            emu_cycle(1);
            u16 hi = bus_read(ctx.regis.pc + 1); // Read high byte
            emu_cycle(1);

            // Combine low and high bytes
            u16 tmp_addr = lo | (hi << 8); // Combine high and low bytes

            ctx.regis.pc += 2; // Increment program counter after fetching 16-bit immediate data
            ctx.fetch_data = bus_read(tmp_addr); // Combine high and low bytes
            emu_cycle(1);

            return;
        }

        default:
            // ctx.fetch_data = 0; // Default case, no data fetched
            printf("Warning: Unhandled addressing mode %d in fetch_data (%02X)\n", 
                ctx.current_inst->mode, ctx.current_opcode);
            exit(-7);   // Exit if an unhandled addressing mode is encountered
            return;
    }
}