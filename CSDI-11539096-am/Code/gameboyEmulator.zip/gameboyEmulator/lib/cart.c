#include <cart.h>
#include <string.h>

typedef struct {
    char filename[1024];
    u32 rom_size;
    u8 *rom_data;
    rom_header *header;

    //mbc1 related data
    bool ram_enabled;
    bool ram_banking;

    u8 *rom_bank_x;
    u8 banking_mode;

    u8 rom_bank_value;
    u8 ram_bank_value;

    u8 *ram_bank; //current selected ram bank
    u8 *ram_banks[16]; //all ram banks

    //for battery
    bool battery; //has battery
    bool is_save; //should save battery backup.
} cart_context;

static cart_context cart_ctx;

bool cart_save() {
    return cart_ctx.is_save;
}

bool cart_mbc1() {
    return BETWEEN(cart_ctx.header->type, 1, 3);
} // MBC1

bool cart_is_battery() {
    return cart_ctx.header->type == 3;
}// Battery

// Reference: https://gbdev.io/pandocs/The_Cartridge_Header.html#cartridgetype
// Array of cartridge types
static const char *ROM_TYPES[] = {
    "ROM ONLY",
    "MBC1",
    "MBC1+RAM",
    "MBC1+RAM+BATTERY",
    "0x04 ???",
    "MBC2",
    "MBC2+BATTERY",
    "0x07 ???",
    "ROM+RAM 1",
    "ROM+RAM+BATTERY 1",
    "0x0A ???",
    "MMM01",
    "MMM01+RAM",
    "MMM01+RAM+BATTERY",
    "0x0E ???",
    "MBC3+TIMER+BATTERY",
    "MBC3+TIMER+RAM+BATTERY 2",
    "MBC3",
    "MBC3+RAM 2",
    "MBC3+RAM+BATTERY 2",
    "0x14 ???",
    "0x15 ???",
    "0x16 ???",
    "0x17 ???",
    "0x18 ???",
    "MBC5",
    "MBC5+RAM",
    "MBC5+RAM+BATTERY",
    "MBC5+RUMBLE",
    "MBC5+RUMBLE+RAM",
    "MBC5+RUMBLE+RAM+BATTERY",
    "0x1F ???",
    "MBC6",
    "0x21 ???",
    "MBC7+SENSOR+RUMBLE+RAM+BATTERY",
    // "POCKET CAMERA",
    // "BANDAI TAMA5",
    // "HuC3",
    // "HuC1+RAM+BATTERY"    
};

// References: https://gbdev.io/pandocs/The_Cartridge_Header.html?highlight=licen#01440145--new-licensee-code
// Array of new licensee codes
static const char *LIC_CODE[0xA5] = {
    [0x00] = "None",
    [0x01] = "Nintendo R&D1",
    [0x08] = "Capcom",
    [0x13] = "Electronic Arts",
    [0x18] = "Hudson Soft",
    [0x19] = "b-ai",
    [0x20] = "kss",
    [0x22] = "pow",
    [0x24] = "PCM Complete",
    [0x25] = "san-x",
    [0x28] = "Kemco Japan",
    [0x29] = "seta",
    [0x30] = "Viacom",
    [0x31] = "Nintendo",
    [0x32] = "Bandai",
    [0x33] = "Ocean/Acclaim",
    [0x34] = "Konami",
    [0x35] = "Hector",
    [0x37] = "Taito",
    [0x38] = "Hudson",
    [0x39] = "Banpresto",
    [0x41] = "Ubi Soft",
    [0x42] = "Atlus",
    [0x44] = "Malibu",
    [0x46] = "angel",
    [0x47] = "Bullet-Proof",
    [0x49] = "irem",
    [0x50] = "Absolute",
    [0x51] = "Acclaim",
    [0x52] = "Activision",
    [0x53] = "American sammy",
    [0x54] = "Konami",
    [0x55] = "Hi tech entertainment",
    [0x56] = "LJN",
    [0x57] = "Matchbox",
    [0x58] = "Mattel",
    [0x59] = "Milton Bradley",
    [0x60] = "Titus",
    [0x61] = "Virgin",
    [0x64] = "LucasArts",
    [0x67] = "Ocean",
    [0x69] = "Electronic Arts",
    [0x70] = "Infogrames",
    [0x71] = "Interplay",
    [0x72] = "Broderbund",
    [0x73] = "sculptured",
    [0x75] = "sci",
    [0x78] = "THQ",
    [0x79] = "Accolade",
    [0x80] = "misawa",
    [0x83] = "lozc",
    [0x86] = "Tokuma Shoten Intermedia",
    [0x87] = "Tsukuda Original",
    [0x91] = "Chunsoft",
    [0x92] = "Video system",
    [0x93] = "Ocean/Acclaim",
    [0x95] = "Varie",
    [0x96] = "Yonezawa/s’pal",
    [0x97] = "Kaneko",
    [0x99] = "Pack in soft",
    [0xA4] = "Konami (Yu-Gi-Oh!)"
};

// Get the licensee name based on the new licensee code
const char *cart_lic_name() {
    if (cart_ctx.header->new_licensee_code <= 0xA4) {
        return LIC_CODE[cart_ctx.header->lic_code];
    }

    return "Unknown Licensee";
}

// Get the cartridge type name based on the cartridge type code
const char *cart_type_name() {
    if (cart_ctx.header->type <= 0x22) {
        return ROM_TYPES[cart_ctx.header->type];
    }

    return "Unknown Cartridge Type";
}

// Setup the cartridge banking
void cart_setup_banking() {
    for (int i = 0; i < 16; i++) {
        cart_ctx.ram_banks[i] = 0;

        // Allocate RAM banks based on the cartridge header
        if ((cart_ctx.header->ram_size == 2 && i == 0) ||
            (cart_ctx.header->ram_size == 3 && i < 4) || 
            (cart_ctx.header->ram_size == 4 && i < 16) || 
            (cart_ctx.header->ram_size == 5 && i < 8)) {
            cart_ctx.ram_banks[i] = malloc(0x2000);
            memset(cart_ctx.ram_banks[i], 0, 0x2000);
        }
    }

    // Setup the initial RAM and ROM banks
    cart_ctx.ram_bank = cart_ctx.ram_banks[0];
    // bank 1
    cart_ctx.rom_bank_x = cart_ctx.rom_data + 0x4000;
}

// Load the cartridge from a file
bool cart_load(char *cart) {
    snprintf(cart_ctx.filename, sizeof(cart_ctx.filename), "%s", cart);

    // Open the cartridge file
    FILE *file = fopen(cart, "r");

    if (!file) {
        printf("Failed to open: %s\n", cart);
        return false; // Return false if the file cannot be opened
    }

    printf("Loading cartridge: %s\n", cart_ctx.filename);

    // Move the file pointer to the end
    fseek(file, 0, SEEK_END);
    // Get the size of the ROM
    cart_ctx.rom_size = ftell(file);

    // Move the file pointer back to the beginning 
    rewind(file);

    // Allocate memory for the ROM data
    cart_ctx.rom_data = malloc(cart_ctx.rom_size);
    // Read the ROM data into memory
    fread(cart_ctx.rom_data, cart_ctx.rom_size, 1, file);
    fclose(file);

    // Set the header pointer to the ROM header location
    cart_ctx.header = (rom_header *)(cart_ctx.rom_data + 0x100);
    // Ensure the title is null-terminated
    cart_ctx.header->title[15] = 0;
    
    // printf("--------------------\n");
    // printf("Cartridge Title: %s\n", cart_ctx.header->title);
    // printf("Cartridge Type: %s\n", cart_type_name());
    // printf("ROM Size: %d KB\n", 32 << cart_ctx.header->rom_size);
    // printf("RAM Size: %d KB\n", 4 << cart_ctx.header->ram_size);
    // printf("Licensee Code: %s\n", cart_lic_name());

    // Check for battery-backed RAM
    cart_ctx.battery = cart_is_battery();
    cart_ctx.is_save = false;

    // Print cartridge information
    printf("--------------------\n");
    printf("\t Cartridge Title  : %s\n", cart_ctx.header->title);
    printf("\t Cartridge Type   : %2.2X (%s)\n", cart_ctx.header->cartridge_type, cart_type_name());
    printf("\t ROM Size         : %d KB\n", 32 << cart_ctx.header->rom_size);
    printf("\t RAM Size         : %2.2X\n", cart_ctx.header->ram_size);
    printf("\t Licensee Code    : %2.2X (%s)\n", cart_ctx.header->lic_code, cart_lic_name());
    printf("\t ROM Version      : %2.2X\n", cart_ctx.header->version);  
    printf("\n--------------------\n");

    cart_setup_banking();

    // 014D - Header Checksum
    u16 x = 0; // CHECKSum calculation
    for (u16 i = 0x0134; i <= 0x014C; i++) {
        x = x - cart_ctx.rom_data[i] - 1;
    }

    printf("\t Checksum : %2.2X (%s)\n", cart_ctx.header->header_checksum, (x & 0xFF) ? "PASSED" : "FAILED");

    // Check for battery-backed RAM
    if (cart_ctx.battery) {
        cart_battery_backed_ram_load(); // Load battery-backed RAM
    }

    return true;
}

// Load battery-backed RAM
void cart_battery_backed_ram_load() {
    if (!cart_ctx.ram_bank) {
        return;
    }

    // Create the filename for the battery-backed RAM
    char fn[1048]; // Filename buffer
    sprintf(fn, "%s.battery", cart_ctx.filename);
    FILE *file = fopen(fn, "rb");

    // Check if the file was opened successfully
    if (!file) {
        fprintf(stderr, "FAILED TO OPEN: %s\n", fn);
        return;
    }

    // Read the RAM data from the file
    fread(cart_ctx.ram_bank, 0x2000, 1, file);
    fclose(file);
}

// Save battery-backed RAM
void cart_battery_backed_ram_save() {
    if (!cart_ctx.ram_bank) {
        return;
    }

    // Create the filename for the battery-backed RAM
    char fn[1048]; // Filename buffer
    sprintf(fn, "%s.battery", cart_ctx.filename);
    FILE *file = fopen(fn, "wb");

    // Check if the file was opened successfully
    if (!file) {
        fprintf(stderr, "FAILED TO OPEN: %s\n", fn);
        return;
    }

    // Write the RAM data to the file
    fwrite(cart_ctx.ram_bank, 0x2000, 1, file);
    fclose(file);
}

// Read from cartridge
u8 cart_read(u16 address) {
    // Check if the address is within the ROM range
    if (!cart_mbc1() || address < 0x4000) {
        return cart_ctx.rom_data[address];
    }

    // Check if the address is within the RAM range
    if ((address & 0xE000) == 0xA000) {
        if (!cart_ctx.ram_enabled) {
            return 0xFF;
        }

        if (!cart_ctx.ram_bank) {
            return 0xFF;
        }

        return cart_ctx.ram_bank[address - 0xA000];
    }

    // Check if the address is within the ROM bank range
    return cart_ctx.rom_bank_x[address - 0x4000];
}

// Write to cartridge
void cart_write(u16 address, u8 value) {
    if (!cart_mbc1()) {
        return; // Not a MBC1 cartridge
    }

    // RAM Enable
    if (address < 0x2000) {
        cart_ctx.ram_enabled = ((value & 0xF) == 0xA);
    }

    // ROM Bank Number
    if ((address & 0xE000) == 0x2000) {
        //rom bank number
        if (value == 0) {
            value = 1;
        }

        // Mask to 5 bits
        value &= 0b11111;

        cart_ctx.rom_bank_value = value;
        cart_ctx.rom_bank_x = cart_ctx.rom_data + (0x4000 * cart_ctx.rom_bank_value);
    }

    // RAM Bank Number
    if ((address & 0xE000) == 0x4000) {
        //ram bank number
        cart_ctx.ram_bank_value = value & 0b11;

        if (cart_ctx.ram_banking) {
            if (cart_save()) {
                cart_battery_backed_ram_save();
            }

            cart_ctx.ram_bank = cart_ctx.ram_banks[cart_ctx.ram_bank_value];
        }
    }

    // Banking Mode Select
    if ((address & 0xE000) == 0x6000) {
        //banking mode select
        cart_ctx.banking_mode = value & 1;
        cart_ctx.ram_banking = cart_ctx.banking_mode;

        if (cart_ctx.ram_banking) {
            if (cart_save()) {
                cart_battery_backed_ram_save();
            }

            cart_ctx.ram_bank = cart_ctx.ram_banks[cart_ctx.ram_bank_value];
        }
    }

    // RAM Read
    if ((address & 0xE000) == 0xA000) {
        if (!cart_ctx.ram_enabled) {
            return; // RAM is not enabled
        }
        if (!cart_ctx.ram_bank) {
            return; // No RAM bank available
        }

        // Write to RAM
        cart_ctx.ram_bank[address - 0xA000] = value;

        if (cart_ctx.battery) {
            cart_ctx.is_save = true;
        }
    }
}

