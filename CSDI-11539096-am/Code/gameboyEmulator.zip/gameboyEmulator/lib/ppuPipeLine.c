#include <bus.h>
#include <ppu.h>
#include <lcd.h>

// Check if the window is visible
bool window_visible() {
    return LCDC_WIN_ENABLE && lcd_get_context()->win_x >= 0 &&
        lcd_get_context()->win_x <= 166 && lcd_get_context()->win_y >= 0 &&
        lcd_get_context()->win_y < YRES;
}

// Push a pixel value into the FIFO
void pixel_fifo_push(u32 value) {
    fifo_entry *next = malloc(sizeof(fifo_entry));
    // Initialize the new FIFO entry
    next->next = NULL;
    next->value = value;

    if (!ppu_get_context()->pfc.pixel_fifo.head) {
        // First entry for pixel FIFO
        ppu_get_context()->pfc.pixel_fifo.head = ppu_get_context()->pfc.pixel_fifo.tail = next;
    } else { // Subsequent entries
        ppu_get_context()->pfc.pixel_fifo.tail->next = next;
        ppu_get_context()->pfc.pixel_fifo.tail = next;
    }

    // Update the FIFO size
    ppu_get_context()->pfc.pixel_fifo.size++;
}

// Pop one pixel from the FIFO
u32 pixel_fifo_pop() {
    if (ppu_get_context()->pfc.pixel_fifo.size <= 0) {
        fprintf(stderr, "ERROR: INVALID POP IN PIXEL FIFO!\n");
        exit(-8);
    }

    // Pop the entry from the FIFO
    fifo_entry *popped = ppu_get_context()->pfc.pixel_fifo.head;
    ppu_get_context()->pfc.pixel_fifo.head = popped->next;
    ppu_get_context()->pfc.pixel_fifo.size--;

    u32 val = popped->value;
    free(popped); // Free the popped entry

    return val;
}

// Fetch sprite pixels and handle priority
u32 fetch_sprite_pixels(int bit, u32 color, u8 bg_color) {
    for (int i=0; i<ppu_get_context()->fetched_entry_count; i++) {
        int sp_x = (ppu_get_context()->fetched_entries[i].x - 8) + 
            ((lcd_get_context()->scroll_x % 8));
        
        if (sp_x + 8 < ppu_get_context()->pfc.fifo_x) {
            //past pixel point already...
            continue;
        }

        // Calculate the offset
        int offset = ppu_get_context()->pfc.fifo_x - sp_x;

        if (offset < 0 || offset > 7) {
            continue; // Out of bounds, then skip
        }

        // Determine the bit position
        bit = (7 - offset);

        if (ppu_get_context()->fetched_entries[i].f_x_flip) {
            bit = offset;
        }

        // Fetch the high and low bits
        u8 hi = !!(ppu_get_context()->pfc.fetch_entry_data[i * 2] & (1 << bit));
        u8 lo = !!(ppu_get_context()->pfc.fetch_entry_data[(i * 2) + 1] & (1 << bit)) << 1;

        // Determine the background priority
        bool bg_priority = ppu_get_context()->fetched_entries[i].f_bgp;

        if (!(hi|lo)) {
            continue; // Transparent pixel, then skip
        }

        // Determine the color
        if (!bg_priority || bg_color == 0) {
            color = (ppu_get_context()->fetched_entries[i].f_pn) ? 
                lcd_get_context()->sp2_colors[hi|lo] : lcd_get_context()->sp1_colors[hi|lo];

            if (hi|lo) {
                break; // Found a non-transparent pixel
            }
        }
    }

    return color;
}

// Fetch sprite and handle priority
bool pipeline_fifo_add() {
    if (ppu_get_context()->pfc.pixel_fifo.size > 8) {
        //fifo is full!
        return false;
    }

    // Calculate the X position
    int x = ppu_get_context()->pfc.fetch_x - (8 - (lcd_get_context()->scroll_x % 8));

    for (int i=0; i<8; i++) {
        int bit = 7 - i;
        u8 hi = !!(ppu_get_context()->pfc.bgw_fetch_data[1] & (1 << bit));
        u8 lo = !!(ppu_get_context()->pfc.bgw_fetch_data[2] & (1 << bit)) << 1;
        // Determine the color
        u32 color = lcd_get_context()->bg_colors[hi | lo];

        // Determine the background priority
        if (!LCDC_BGW_ENABLE) {
            color = lcd_get_context()->bg_colors[0];
        }

        // Fetch sprite pixels and handle priority
        if (LCDC_OBJ_ENABLE) {
            color = fetch_sprite_pixels(bit, color, hi | lo);
        }

        if (x >= 0) {
            pixel_fifo_push(color);
            ppu_get_context()->pfc.fifo_x++;
        }
    }

    return true;
}

// Load sprite tiles into the pipeline
void pipeline_load_sprite_tile() {
    oam_line_entry *le = ppu_get_context()->line_sprites;

    while(le) { // Iterate through the line sprite entries
        int sp_x = (le->entry.x - 8) + (lcd_get_context()->scroll_x % 8);

        // Check if the sprite is within the fetch window
        if ((sp_x >= ppu_get_context()->pfc.fetch_x && sp_x < ppu_get_context()->pfc.fetch_x + 8) ||
            ((sp_x + 8) >= ppu_get_context()->pfc.fetch_x && (sp_x + 8) < ppu_get_context()->pfc.fetch_x + 8)) {
            // Need to add entry
            ppu_get_context()->fetched_entries[ppu_get_context()->fetched_entry_count++] = le->entry;
        }

        le = le->next; // Move to the next sprite entry

        if (!le || ppu_get_context()->fetched_entry_count >= 3) {
            break; // Max checking 3 sprites on pixels
        }
    }
}

// Load the sprite data
void pipeline_load_sprite_data(u8 offset) {
    int cur_y = lcd_get_context()->ly;
    u8 sprite_height = LCDC_OBJ_HEIGHT;

    for (int i = 0; i < ppu_get_context()->fetched_entry_count; i++) {
        // Calculate the tile Y position
        u8 ty = ((cur_y + 16) - ppu_get_context()->fetched_entries[i].y) * 2;

        if (ppu_get_context()->fetched_entries[i].f_y_flip) {
            ty = ((sprite_height * 2) - 2) - ty; // Flipped upside down
        }

        u8 tile_index = ppu_get_context()->fetched_entries[i].tile;

        if (sprite_height == 16) { // 16x16 sprites
            tile_index &= ~(1); // Remove last bit because 16x16 sprites use a different tile mapping
        }

        // Load the sprite tile data
        ppu_get_context()->pfc.fetch_entry_data[(i * 2) + offset] = 
            bus_read(0x8000 + (tile_index * 16) + ty + offset);
    }
}


// Load the window tile data
void pipeline_load_window_tile() {
    if (!window_visible()) {
        return;
    }

    // Get the window Y position
    u8 window_y = lcd_get_context()->win_y;

    if (ppu_get_context()->pfc.fetch_x + 7 >= lcd_get_context()->win_x &&
            ppu_get_context()->pfc.fetch_x + 7 < lcd_get_context()->win_x + YRES + 14) { // Check if the fetch window overlaps with the window
        if (lcd_get_context()->ly >= window_y && lcd_get_context()->ly < window_y + XRES) {
            u8 w_tile_y = ppu_get_context()->window_line / 8;

            // Get the window tile X position
            ppu_get_context()->pfc.bgw_fetch_data[0] = bus_read(LCDC_WIN_MAP_AREA + 
                ((ppu_get_context()->pfc.fetch_x + 7 - lcd_get_context()->win_x) / 8) +
                (w_tile_y * 32));

            if (LCDC_BGW_DATA_AREA == 0x8800) {
                ppu_get_context()->pfc.bgw_fetch_data[0] += 128;
            }
        }
    }
}

// Load the sprite data
void pipeline_fetch() {
    switch(ppu_get_context()->pfc.cur_fetch_state) {
        case FS_TILE: { // Fetch tile data
            ppu_get_context()->fetched_entry_count = 0;

            if (LCDC_BGW_ENABLE) {
                ppu_get_context()->pfc.bgw_fetch_data[0] = bus_read(LCDC_BG_MAP_AREA + 
                    (ppu_get_context()->pfc.map_x / 8) + 
                    (((ppu_get_context()->pfc.map_y / 8)) * 32));
            
                if (LCDC_BGW_DATA_AREA == 0x8800) {
                    ppu_get_context()->pfc.bgw_fetch_data[0] += 128;
                }

                pipeline_load_window_tile();
            }

            if (LCDC_OBJ_ENABLE && ppu_get_context()->line_sprites) {
                pipeline_load_sprite_tile();
            }

            ppu_get_context()->pfc.cur_fetch_state = FS_DATA0;
            ppu_get_context()->pfc.fetch_x += 8;
        } break;

        case FS_IDLE: { // Idle state
            ppu_get_context()->pfc.cur_fetch_state = FS_PUSH;
        } break;

        case FS_PUSH: { // Push data to FIFO
            if (pipeline_fifo_add()) {
                ppu_get_context()->pfc.cur_fetch_state = FS_TILE;
            }

        } break;

        case FS_DATA0: { // Fetch background data
            ppu_get_context()->pfc.bgw_fetch_data[1] = bus_read(LCDC_BGW_DATA_AREA +
                (ppu_get_context()->pfc.bgw_fetch_data[0] * 16) + 
                ppu_get_context()->pfc.tile_y);

            pipeline_load_sprite_data(0);

            ppu_get_context()->pfc.cur_fetch_state = FS_DATA1;
        } break;

        case FS_DATA1: { // Fetch background data
            ppu_get_context()->pfc.bgw_fetch_data[2] = bus_read(LCDC_BGW_DATA_AREA +
                (ppu_get_context()->pfc.bgw_fetch_data[0] * 16) + 
                ppu_get_context()->pfc.tile_y + 1);

            pipeline_load_sprite_data(1);

            ppu_get_context()->pfc.cur_fetch_state = FS_IDLE;

        } break;

    }
}


// Push the pixel data to the video buffer
void pipeline_push_pixel() {
    if (ppu_get_context()->pfc.pixel_fifo.size > 8) {
        u32 pixel_data = pixel_fifo_pop();

        if (ppu_get_context()->pfc.line_x >= (lcd_get_context()->scroll_x % 8)) {
            ppu_get_context()->video_buffer[ppu_get_context()->pfc.pushed_x + 
                (lcd_get_context()->ly * XRES)] = pixel_data;

            // Increment the pushed X position
            ppu_get_context()->pfc.pushed_x++;
        }

        // Increment the line X position
        ppu_get_context()->pfc.line_x++;
    }
}


// Process the pipeline
void pipeline_process() {
    ppu_get_context()->pfc.map_y = (lcd_get_context()->ly + lcd_get_context()->scroll_y);
    ppu_get_context()->pfc.map_x = (ppu_get_context()->pfc.fetch_x + lcd_get_context()->scroll_x);
    ppu_get_context()->pfc.tile_y = ((lcd_get_context()->ly + lcd_get_context()->scroll_y) % 8) * 2;

    if (!(ppu_get_context()->line_ticks & 1)) {
        pipeline_fetch(); // Fetch the tile and sprite data
    }

    // Push the pixel data to the video buffer
    pipeline_push_pixel();
}


// Reset the FIFO buffer
void pipeline_fifo_reset() {
    while(ppu_get_context()->pfc.pixel_fifo.size) {
        pixel_fifo_pop();
    }

    // Reset the FIFO buffer
    ppu_get_context()->pfc.pixel_fifo.head = 0;
}