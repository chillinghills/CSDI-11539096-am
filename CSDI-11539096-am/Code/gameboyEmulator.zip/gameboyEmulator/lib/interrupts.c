#include <cpu.h>
#include <stack.h>
#include <interrupts.h>

#define ISR_VBLANK   0x0040
#define ISR_LCD_STAT 0x0048
#define ISR_TIMER    0x0050
#define ISR_SERIAL   0x0058
#define ISR_JOYPAD   0x0060

// Handle an interrupt
void int_handle(cpu_context *ctx, u16 address) {
    stack_push16(ctx->regis.pc);
    // Set the interrupt flag
    ctx->regis.pc = address;
}

// Check if the interrupt is enabled and pending
bool int_check(cpu_context *ctx, u16 address, interrupt_type it) {
    if (ctx->int_flags & it && ctx->ie_regis & it) {
        // Handle the interrupt
        int_handle(ctx, address);

        // Clear the interrupt flag
        ctx->int_flags &= ~it;
        ctx->halted = false;
        ctx->int_master_enabled = false;

        return true;
    }

    return false;
}

// Handle CPU interrupts
void cpu_handle_interrupts(cpu_context *ctx) {
    NO_IMPLEMENTATION
    // This function should check for pending interrupts and handle them
}

