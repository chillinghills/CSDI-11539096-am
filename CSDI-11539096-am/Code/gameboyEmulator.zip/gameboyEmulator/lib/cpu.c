#include <cpu.h>
#include <bus.h>
#include <emu.h>
#include <interrupts.h>
#include <dbg.h>
#include <timer.h>

cpu_context ctx = {0}; // CPU context

// Debug mode: Developer only
#define CPU_DEBUG 0 

void cpu_init() {
    ctx.regis.pc = 0x100;
    ctx.regis.sp = 0xFFFE;
    // Initialize 16-bit registers
    *((short *)&ctx.regis.a) = 0xB001;
    *((short *)&ctx.regis.b) = 0x1300;
    *((short *)&ctx.regis.d) = 0xD800;
    *((short *)&ctx.regis.h) = 0x4D01;

    // Initialize interrupt registers
    ctx.ie_regis = 0;
    ctx.int_flags = 0;
    ctx.int_master_enabled = false;
    ctx.is_iME = false;

    // Initialize timer
    timer_get_context()->div = 0xABCC;
}

// Fetch next instructions
static void fetch_instruction() {
    ctx.current_opcode = bus_read(ctx.regis.pc++);
    ctx.current_inst = instruction_by_opcode(ctx.current_opcode);
}

// Fetch data for the current instruction
void do_fetch_data();

// Execute the current instruction
static void execute() {
    IN_PROC proc = inst_get_processor(ctx.current_inst->type);

    if (!proc) {
        NO_IMPLEMENTATION
    }

    proc(&ctx);
}

// CPU step function
bool cpu_step() {
    
    if (!ctx.halted) {
        u16 pc = ctx.regis.pc;

        fetch_instruction();
        emu_cycles(1);
        do_fetch_data();

#if CPU_DEBUG == 1
        char current_flg[16], inst[16];
        sprintf(current_flg, "%c%c%c%c", 
            ctx.regis.f & (1 << 7) ? 'Z' : '-',
            ctx.regis.f & (1 << 6) ? 'N' : '-',
            ctx.regis.f & (1 << 5) ? 'H' : '-',
            ctx.regis.f & (1 << 4) ? 'C' : '-'
        );

        inst_to_str(&ctx, inst);

        printf("%08lX - %04X: %-12s (%02X %02X %02X) A: %02X F: %s BC: %02X%02X DE: %02X%02X HL: %02X%02X\n", 
            emu_get_context()->ticks,
            pc, inst, ctx.current_opcode,
            bus_read(pc + 1), bus_read(pc + 2), ctx.regis.a, flags, ctx.regis.b, ctx.regis.c,
            ctx.regis.d, ctx.regis.e, ctx.regis.h, ctx.regis.l);
#endif
        // Check for unknown instruction
        if (ctx.current_inst == NULL) {
            printf("Unknown Instruction! %02X\n", ctx.current_opcode);
            exit(-7);
        }

        dbg_update();
        dbg_print();
        execute();
        
    } else {
        // CPU is halted
        emu_cycles(1);

        if (ctx.int_flags) {
            ctx.halted = false;
        }
    }

    // Check for interrupts
    if (ctx.int_master_enabled) {
        cpu_handle_interrupts(&ctx);
        ctx.is_iME = false;
    }

    // Check if Interrupt Master Enable (IME) is set
    if (ctx.is_iME) {
        ctx.int_master_enabled = true;
    }

    return true;
}

u8 cpu_get_ie_regis() {
    return ctx.ie_regis;
} // Get the Interrupt Enable register

void cpu_set_ie_regis(u8 n) {
    ctx.ie_regis = n;
} // Set the Interrupt Enable register

void cpu_request_interrupt(interrupt_type t) {
    ctx.int_flags |= t;
} // Request an interrupt
