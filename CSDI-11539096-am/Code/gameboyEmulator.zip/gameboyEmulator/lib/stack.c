#include <stack.h>
#include <cpu.h>
#include <bus.h>

static inline cpu_registers* regs(void) {
    return cpu_get_regis(); // Get the current CPU registers
}

void stack_push(u8 data) {
    // cpu_get_regis()->sp--; // Decrement stack pointer
    regs()->sp--; // Decrement stack pointer
    bus_write(regs()->sp, data); // Write value to the stack
}

void stack_push16(u16 data) {
    // u16 lo = value; // Get low byte
    // u16 hi = value >> 8; // Get high byte
    stack_push((data >> 8) & 0xFF); // Push high byte
    stack_push(data & 0xFF);        // Push low byte
}

u8 stack_pop() {
    // u8 value = bus_read(ctx.regis.sp); // Read value from the
    // ctx.regis.sp++; // Increment stack pointer
    // return value; // Return the popped value
    return bus_read(regs()->sp++); // Read value from the stack and increment stack pointer
    // return bus_read(cpu_get_regis()->sp++); // Read value from the stack and increment stack pointer
}

u16 stack_pop16() {
    // u8 val = stack_pop(); // Read low byte
    // return (val & 0xFF); // Return low byte

    u8 lo = stack_pop(); // Read low byte
    u8 hi = stack_pop(); // Read high byte
    return (hi << 8) | lo; // Combine high and low bytes and return
}
