#include <cpu.h>
#include <bus.h>

extern cpu_context ctx; // CPU context

u16 reverse(u16 n) {
    return ((n & 0xFF00) >> 8) | ((n & 0x00FF) << 8);
}

//// 16-bit registers
// Read a 16-bit register
u16 cpu_read_regis(reg_type rt) {
    switch(rt) {
        case RT_A: return ctx.regis.a;
        case RT_F: return ctx.regis.f;
        case RT_B: return ctx.regis.b;
        case RT_C: return ctx.regis.c;
        case RT_D: return ctx.regis.d;
        case RT_E: return ctx.regis.e;
        case RT_H: return ctx.regis.h;
        case RT_L: return ctx.regis.l;

        case RT_AF: return reverse(*((u16 *)&ctx.regis.a));
        case RT_BC: return reverse(*((u16 *)&ctx.regis.b));
        case RT_DE: return reverse(*((u16 *)&ctx.regis.d));
        case RT_HL: return reverse(*((u16 *)&ctx.regis.h));

        case RT_PC: return ctx.regis.pc;
        case RT_SP: return ctx.regis.sp;
        default: return 0;
    }
}

// Set a 16-bit register
void cpu_set_reg(reg_type rt, u16 val) {
    switch(rt) {
        // 8-bit registers
        case RT_A: ctx.regis.a = val & 0xFF; break;
        case RT_F: ctx.regis.f = val & 0xFF; break;
        case RT_B: ctx.regis.b = val & 0xFF; break;
        case RT_C: {
             ctx.regis.c = val & 0xFF;
        } break;
        case RT_D: ctx.regis.d = val & 0xFF; break;
        case RT_E: ctx.regis.e = val & 0xFF; break;
        case RT_H: ctx.regis.h = val & 0xFF; break;
        case RT_L: ctx.regis.l = val & 0xFF; break;

        // 16-bit registers
        case RT_AF: *((u16 *)&ctx.regis.a) = reverse(val); break;
        case RT_BC: *((u16 *)&ctx.regis.b) = reverse(val); break;
        case RT_DE: *((u16 *)&ctx.regis.d) = reverse(val); break;
        case RT_HL: {
         *((u16 *)&ctx.regis.h) = reverse(val); // Reverse the byte order
         break;
        }

        // 16-bit registers
        case RT_PC: ctx.regis.pc = val; break;
        case RT_SP: ctx.regis.sp = val; break;
        case RT_NONE: break;
    }
}


//// 8-bit registers
// Read an 8-bit register
u8 cpu_read_regis8(reg_type rt) {
    switch(rt) {
        // 8-bit registers
        case RT_A: return ctx.regis.a;
        case RT_F: return ctx.regis.f;
        case RT_B: return ctx.regis.b;
        case RT_C: return ctx.regis.c;
        case RT_D: return ctx.regis.d;
        case RT_E: return ctx.regis.e;
        case RT_H: return ctx.regis.h;
        case RT_L: return ctx.regis.l;

        // RT_HL means the pair of registers (H, L)
        case RT_HL: {
            return bus_read(cpu_read_regis(RT_HL));
        }
        default:
            printf("**ERROR: INVALID REGIS8: %d\n", rt);
            NO_IMPLEMENTATION
    }
}

// Set an 8-bit register
void cpu_set_reg8(reg_type rt, u8 val) {
    switch(rt) {
        // 8-bit registers
        case RT_A: ctx.regis.a = val & 0xFF; break;
        case RT_F: ctx.regis.f = val & 0xFF; break;
        case RT_B: ctx.regis.b = val & 0xFF; break;
        case RT_C: ctx.regis.c = val & 0xFF; break;
        case RT_D: ctx.regis.d = val & 0xFF; break;
        case RT_E: ctx.regis.e = val & 0xFF; break;
        case RT_H: ctx.regis.h = val & 0xFF; break;
        case RT_L: ctx.regis.l = val & 0xFF; break;

        // RT_HL means the pair of registers (H, L)
        case RT_HL: bus_write(cpu_read_regis(RT_HL), val); break;
        default:
            printf("**ERROR: INVALID REGIS8: %d\n", rt);
            NO_IMPLEMENTATION
    }
}

cpu_registers *cpu_get_regis() {
    return &ctx.regis;
} // Get the CPU registers

// Interrupt flags
void cpu_set_int_flags(u8 value) {
    ctx.int_flags = value;
}
u8 cpu_get_int_flags() {
    return ctx.int_flags;
}

