#include <dma.h>
#include <ppu.h>
#include <bus.h>

typedef struct {
    bool active;
    u8 byte;
    u8 value;
    u8 start_delay;
} dma_context;

static dma_context ctx; // DMA context

void dma_start(u8 start) {
    ctx.byte = 0; // Reset byte counter
    ctx.active = true; // Set DMA active
    ctx.start_delay = 2;
    ctx.value = start;
} // dma_start

void dma_tick() {
    if (!ctx.active) {
        return;
    }
    if (ctx.start_delay) {
        ctx.start_delay--;
        return;
    }

    ppu_oam_write(ctx.byte, bus_read((ctx.value * 0x100) + ctx.byte));

    // Increment the byte counter and check if the transfer is complete
    ctx.byte++;
    ctx.active = ctx.byte < 0xA0;
}

// Check if DMA is currently transferring data
bool dma_transferring() {
    return ctx.active;
}

