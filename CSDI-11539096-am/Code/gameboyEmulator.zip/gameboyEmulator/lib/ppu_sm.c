#include <string.h>
#include <cart.h>
#include <cpu.h>
#include <ppu.h>
#include <lcd.h>
#include <interrupts.h>s

// Reset the FIFO buffer
void pipeline_fifo_reset();
void pipeline_process();
bool window_visible();

// Increment the window line
void increment_ly() {
    if (window_visible() && lcd_get_context()->ly >= lcd_get_context()->win_y &&
        lcd_get_context()->ly < lcd_get_context()->win_y + YRES) {
            ppu_get_context()->window_line++;
    }

    lcd_get_context()->ly++;

    if (lcd_get_context()->ly == lcd_get_context()->ly_compare) {
        LCDS_LYC_SET(1);

        if (LCDS_STAT_INT(SS_LYC)) {
            cpu_request_interrupt(IT_LCD_STAT);
        }
    } else {
        LCDS_LYC_SET(0);
    }
}


// Load the line sprites for the choice of the modes
void load_line_sprites() {
    int cur_y = lcd_get_context()->ly;

    u8 sprite_height = LCDC_OBJ_HEIGHT;
    // Clear the line entry array
    memset(ppu_get_context()->line_entry_array, 0, 
        sizeof(ppu_get_context()->line_entry_array));

    for (int i=0; i<40; i++) {
        oam_entry e = ppu_get_context()->oam_ram[i];
        
        // Check if the sprite is visible
        if (!e.x) {
            continue; // Not visible
        }

        if (ppu_get_context()->line_sprite_count >= 10) {
            break; // Max 10 sprites per line; else quit
        }

        if (e.y <= cur_y + 16 && e.y + sprite_height > cur_y + 16) {
            //this sprite is on the current line.

            oam_line_entry *entry = &ppu_get_context()->line_entry_array[
                ppu_get_context()->line_sprite_count++
            ];

            entry->entry = e;
            entry->next = NULL;

            if (!ppu_get_context()->line_sprites ||
                    ppu_get_context()->line_sprites->entry.x > e.x) {
                entry->next = ppu_get_context()->line_sprites;
                ppu_get_context()->line_sprites = entry;
                continue;
            }

            //do some sorting...

            oam_line_entry *le = ppu_get_context()->line_sprites;
            oam_line_entry *prev = le;

            // Insert the new entry in the correct position
            while(le) {
                if (le->entry.x > e.x) {
                    prev->next = entry;
                    entry->next = le;
                    break;
                }

                if (!le->next) {
                    le->next = entry;
                    break; // If we reached the end of the list, insert the entry here
                }

                // Move to the next entry
                prev = le;
                le = le->next;
            }
        }
    }
}



// Load the line sprites
// oam mode
void ppu_mode_oam() {
    // Check if needed to switch to transfer mode
    if (ppu_get_context()->line_ticks >= 80) {
        LCDS_MODE_SET(MODE_XFER); // Switch to transfer mode
        ppu_get_context()->pfc.cur_fetch_state = FS_TILE;
        ppu_get_context()->pfc.line_x = 0;
        ppu_get_context()->pfc.fetch_x = 0;
        ppu_get_context()->pfc.pushed_x = 0;
        ppu_get_context()->pfc.fifo_x = 0;
    }


    // Clear the line entry array
    if (ppu_get_context()->line_ticks == 1) {
        ppu_get_context()->line_sprites = 0; // Clear the line sprite list
        ppu_get_context()->line_sprite_count = 0; // Clear the line sprite count

        // Load the line sprites
        load_line_sprites();
    }
}


// VBlank mode
void ppu_mode_vblank() {
    if (ppu_get_context()->line_ticks >= TICKS_PER_LINE) {
        increment_ly();

        if (lcd_get_context()->ly >= LINES_PER_FRAME) {
            LCDS_MODE_SET(MODE_OAM);
            lcd_get_context()->ly = 0;
            ppu_get_context()->window_line = 0;
        }

        ppu_get_context()->line_ticks = 0;
    }
}


// Load the line sprites
void ppu_mode_xfer() {
    pipeline_process();

    if (ppu_get_context()->pfc.pushed_x >= XRES) {
        pipeline_fifo_reset();

        // Switch to HBlank mode
        LCDS_MODE_SET(MODE_HBLANK);

        if (LCDS_STAT_INT(SS_HBLANK)) {
            cpu_request_interrupt(IT_LCD_STAT); // Request LCD STAT interrupt
        }
    }
}

// Timing variables
static u32 target_frame_time = 1000 / 60;
static long prev_frame_time = 0;
static long start_timer = 0;
static long frame_count = 0;


// HBlank mode
void ppu_mode_hblank() {
    if (ppu_get_context()->line_ticks >= TICKS_PER_LINE) {
        increment_ly();

        // Check if we need to switch to VBlank mode
        if (lcd_get_context()->ly >= YRES) {
            LCDS_MODE_SET(MODE_VBLANK);

            // Request VBlank interrupt
            cpu_request_interrupt(IT_VBLANK);

            if (LCDS_STAT_INT(SS_VBLANK)) {
                cpu_request_interrupt(IT_LCD_STAT);
            }

            ppu_get_context()->current_frame++;

            u32 end = get_ticks();
            u32 frame_time = end - prev_frame_time;

            // If the frame took too long, delay the next frame
            if (frame_time < target_frame_time) {
                delay((target_frame_time - frame_time));
            }

            // Calculate FPS
            if (end - start_timer >= 1000) {
                u32 fps = frame_count;
                start_timer = end;
                frame_count = 0;

                printf("FPS: %d\n", fps);

                if (cart_need_save()) {
                    cart_battery_save(); // Save the cartridge state
                }
            }

            // Update frame count and previous frame time
            frame_count++;
            prev_frame_time = get_ticks();

        } else {
            LCDS_MODE_SET(MODE_OAM); // Switch to OAM mode
        }

        // Reset line ticks
        ppu_get_context()->line_ticks = 0;
    }
}

