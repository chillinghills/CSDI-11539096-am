#include <string.h>
#include <ppu.h>
#include <lcd.h>
#include <ppuStateMachine.h>


// Pipeline functions
void pipeline_fifo_reset();
void pipeline_process();

static ppu_context ctx;

ppu_context *ppu_get_context() {
    return &ctx; // Get the PPU context
}


// Initialize the PPU context
void ppu_init() {
    // Allocate memory for the video buffer
    ctx.current_frame = 0;
    ctx.line_ticks = 0;
    ctx.video_buffer = malloc(YRES * XRES * sizeof(32));

    // Initialize the pixel buffer
    ctx.pfc.line_x = 0;
    ctx.pfc.pushed_x = 0;
    ctx.pfc.fetch_x = 0;

    // Initialize the pixel FIFO
    ctx.pfc.pixel_fifo.size = 0;
    ctx.pfc.pixel_fifo.head = ctx.pfc.pixel_fifo.tail = NULL;

    // Initialize the fetch state
    ctx.pfc.cur_fetch_state = FS_TILE;

    // Initialize the sprite state
    ctx.line_sprites = 0;
    ctx.fetched_entry_count = 0;
    ctx.window_line = 0;

    // Initialize the LCD
    lcd_init();
    LCDS_MODE_SET(MODE_OAM);

    // Clear the OAM RAM and video buffer
    memset(ctx.oam_ram, 0, sizeof(ctx.oam_ram));
    memset(ctx.video_buffer, 0, YRES * XRES * sizeof(u32));
}

void ppu_tick() {
    ctx.line_ticks++; // Increment line ticks

    // Switch the most appropriate PPU mode among 4
    switch(LCDS_MODE) { // Switch between different PPU modes
    case MODE_OAM:
        ppu_mode_oam();
        break;
    case MODE_XFER:
        ppu_mode_xfer();
        break;
    case MODE_VBLANK:
        ppu_mode_vblank();
        break;
    case MODE_HBLANK:
        ppu_mode_hblank();
        break;
    }
}

//// -----OAM-----
// OAM (Object Attribute Memory) write function
void ppu_oam_write(u16 addr, u8 value) {
    if (addr >= 0xFE00) {
        addr -= 0xFE00;
    }

    // Write the value to OAM RAM
    u8 *p = (u8 *)ctx.oam_ram;
    // // Check if the address is within the OAM range
    // if (address < 0xA0) {
    //     p[address] = value;
    // }
    p[addr] = value;
    // Update the OAM DMA transfer state
}
// OAM (Object Attribute Memory) read function
u8 ppu_oam_read(u16 addr) {
    if (addr >= 0xFE00) {
        addr -= 0xFE00;
    }

    u8 *p = (u8 *)ctx.oam_ram;
    return p[addr];
}

//// -----VRAM-----

// VRAM (Video RAM) write function
void ppu_vram_write(u16 addr, u8 value) {
    ctx.vram[addr - 0x8000] = value;
}
// VRAM (Video RAM) read function
u8 ppu_vram_read(u16 addr) {
    return ctx.vram[addr - 0x8000];
}

