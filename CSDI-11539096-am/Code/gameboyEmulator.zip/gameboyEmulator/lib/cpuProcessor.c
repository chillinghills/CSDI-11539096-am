#include <cpu.h>
#include <emu.h>
#include <bus.h>
#include <stack.h>

// Function prototypes for <instruction processors>

// Pre-Functions
void cpu_set_flags(cpu_context *ctx, int8_t z, int8_t n, int8_t h, int8_t c) {
    if (z != -1) { BIT_SET(ctx->regis.f, 7, z); }
    if (n != -1) { BIT_SET(ctx->regis.f, 6, n); }
    if (h != -1) { BIT_SET(ctx->regis.f, 5, h); }
    if (c != -1) { BIT_SET(ctx->regis.f, 4, c); }
}

// Invalid instruction
static void proc_none(cpu_context *ctx) {
    printf("INVALID INSTRUCTION!\n");
    exit(-7);
}

// NOP instruction - do nothing
static void proc_nop(cpu_context *ctx) {}

reg_type rt_lookup[] = {
    RT_B, RT_C,
    RT_D, RT_E,
    RT_H, RT_L,
    RT_HL, RT_A
}; // Lookup table for register types

// Decode register
reg_type decode_reg(u8 reg) {
    if (reg > 0b111) {
        return RT_NONE;
    }

    return rt_lookup[reg];
}

// CB instruction processing
static void proc_cb(cpu_context *ctx) {
    // Fetch the register value
    u8 op = ctx->fetch_data;
    // Decode the register
    reg_type reg = decode_reg(op & 0b111);

    // Fetch the bit and bit operation
    u8 bit = (op >> 3) & 0b111;
    u8 bit_op = (op >> 6) & 0b11;
    u8 reg_val = cpu_read_regis8(reg);
    emu_cycle(1);

    // For operation RT_HL, fetch the next byte
    if (reg == RT_HL) {
        emu_cycle(2);
    }

    // Bit manipulation
    switch(bit_op) {
        case 1:
            //BIT
            cpu_set_flags(ctx, !(reg_val & (1 << bit)), 0, 1, -1);
            return;
        case 2:
            //RST
            reg_val &= ~(1 << bit);
            cpu_set_reg8(reg, reg_val);
            return;
        case 3:
            //SET
            reg_val |= (1 << bit);
            cpu_set_reg8(reg, reg_val);
            return;
    }

    // Flag C
    bool flagC = CPU_FLAG_C;

    // Bit manipulation
    switch(bit) {
        case 0: {
            //RLC
            bool setC = false;
            u8 result = (reg_val << 1) & 0xFF;

            // Check if the highest bit was set
            if ((reg_val & (1 << 7)) != 0) {
                result |= 1;
                setC = true;
            }
            // Update the register and flags
            cpu_set_reg8(reg, result);
            cpu_set_flags(ctx, result == 0, false, false, setC);
        } return;
        case 1: {
            //RRC
            u8 old = reg_val;
            reg_val >>= 1;
            reg_val |= (old << 7);

            // Update the register and flags
            cpu_set_reg8(reg, reg_val);
            cpu_set_flags(ctx, !reg_val, false, false, old & 1);
        } return;

        case 2: {
            //RL
            u8 old = reg_val;
            reg_val <<= 1;
            reg_val |= flagC;

            // Update the register and flags
            cpu_set_reg8(reg, reg_val);
            cpu_set_flags(ctx, !reg_val, false, false, !!(old & 0x80));
        } return;


        case 3: {
            //RR
            u8 old = reg_val;
            reg_val >>= 1;

            // Update the carry flag
            reg_val |= (flagC << 7);

            // Update the register and flags
            cpu_set_reg8(reg, reg_val);
            cpu_set_flags(ctx, !reg_val, false, false, old & 1);
        } return;

        case 4: {
            //SLA
            u8 old = reg_val;
            reg_val <<= 1;

            // Update the register and flags
            cpu_set_reg8(reg, reg_val);
            cpu_set_flags(ctx, !reg_val, false, false, !!(old & 0x80));
        } return;
        case 5: {
            //SRA
            u8 u = (int8_t)reg_val >> 1;
            
            // Update the register and flags
            cpu_set_reg8(reg, u);
            cpu_set_flags(ctx, !u, 0, 0, reg_val & 1);
        } return;

        case 6: {
            //SWAP
            reg_val = ((reg_val & 0xF0) >> 4) | ((reg_val & 0xF) << 4);
            
            // Update the register and flags
            cpu_set_reg8(reg, reg_val);
            cpu_set_flags(ctx, reg_val == 0, false, false, false);
        } return;
        case 7: {
            //SRL
            u8 u = reg_val >> 1;
            
            // Update the register and flags
            cpu_set_reg8(reg, u);
            cpu_set_flags(ctx, !u, 0, 0, reg_val & 1);
        } return;
    }

    fprintf(stderr, "ERROR: INVALID CB: %02X", op);
    NO_IMPLEMENTATION
}

// Rotate left through carry
static void proc_rlca(cpu_context *ctx) {
    u8 u = ctx->regis.a;
    bool c = (u >> 7) & 1;
    u = (u << 1) | c;
    ctx->regis.a = u;

    // Update the carry flag
    cpu_set_flags(ctx, 0, 0, 0, c);
}

// Rotate right through carry
static void proc_rrca(cpu_context *ctx) {
    u8 b = ctx->regis.a & 1;
    ctx->regis.a >>= 1;
    ctx->regis.a |= (b << 7);

    // Update the carry flag
    cpu_set_flags(ctx, 0, 0, 0, b);
}
// Rotate left
static void proc_rla(cpu_context *ctx) {
    u8 u = ctx->regis.a;
    u8 cf = CPU_FLAG_C;
    u8 c = (u >> 7) & 1;

    ctx->regis.a = (u << 1) | cf;
    cpu_set_flags(ctx, 0, 0, 0, c);
}

// Stop
static void proc_stop(cpu_context *ctx) {
    fprintf(stderr, "Oh, let's break it down!\n");
}

// Decimal Adjust for Addition
static void proc_daa(cpu_context *ctx) {
    u8 u = 0; // adjustment value
    int fc = 0; // carry flag

    // Check for half-carry
    if (CPU_FLAG_H || (!CPU_FLAG_N && (ctx->regis.a & 0xF) > 9)) {
        u = 6;
    }

    // Check for carry
    if (CPU_FLAG_C || (!CPU_FLAG_N && ctx->regis.a > 0x99)) {
        u |= 0x60;
        fc = 1;
    }

    // Update the register
    ctx->regis.a += CPU_FLAG_N ? -u : u;

    // Update the flags
    cpu_set_flags(ctx, ctx->regis.a == 0, -1, 0, fc);
}

static void proc_cpl(cpu_context *ctx) {
    ctx->regis.a = ~ctx->regis.a;
    cpu_set_flags(ctx, -1, 1, 1, -1);
} // CPL

static void proc_scf(cpu_context *ctx) {
    cpu_set_flags(ctx, -1, 0, 0, 1);
} // SCF

static void proc_ccf(cpu_context *ctx) {
    cpu_set_flags(ctx, -1, 0, 0, CPU_FLAG_C ^ 1);
} // CCF

static void proc_halt(cpu_context *ctx) {
    ctx->halted = true;
} // HALT

// Rotate right through carry
static void proc_rra(cpu_context *ctx) {
    u8 carry = CPU_FLAG_C;
    u8 new_c = ctx->regis.a & 1;

    ctx->regis.a >>= 1;
    ctx->regis.a |= (carry << 7);

    cpu_set_flags(ctx, 0, 0, 0, new_c);
}

// Logical OR
static void proc_or(cpu_context *ctx) {
    ctx->regis.a |= ctx->fetch_data & 0xFF;
    cpu_set_flags(ctx, ctx->regis.a == 0, 0, 0, 0);
}

// Logical Compare
static void proc_cp(cpu_context *ctx) {
    int n = (int)ctx->regis.a - (int)ctx->fetch_data;

    cpu_set_flags(ctx, n == 0, 1,
        ((int)ctx->regis.a & 0x0F) - ((int)ctx->fetch_data & 0x0F) < 0, n < 0);
}

// Logical AND
static void proc_and(cpu_context *ctx) {
    ctx->regis.a &= ctx->fetch_data;
    cpu_set_flags(ctx, ctx->regis.a == 0, 0, 1, 0);
}

// Logical XOR
static void proc_xor(cpu_context *ctx) {
    ctx->regis.a ^= ctx->fetch_data & 0xFF;
    cpu_set_flags(ctx, ctx->regis.a == 0, 0, 0, 0);
}

////-----Interrupts-----
// Disable Interrupts
static void proc_di(cpu_context *ctx) {
    ctx->int_master_enabled = false;
}
// Enable Interrupts
static void proc_ei(cpu_context *ctx) {
    ctx->is_iME = true;
}

// Check if the register is 16-bit
static bool is_16_bit(reg_type rt) {
    return rt >= RT_AF;
}

////
// Load Data
static void proc_ld(cpu_context *ctx) {
    if (ctx->flg_mem_dest) {

        // Check if the destination is a 16-bit register
        if (is_16_bit(ctx->current_inst->reg_2)) {
            emu_cycle(1);
            bus_write16(ctx->mem_dest, ctx->fetch_data);
        } else { // 8-bit register
            bus_write(ctx->mem_dest, ctx->fetch_data);
        }

        emu_cycle(1);

        return;
    }

    // Check if the instruction is using the HL register pair
    if (ctx->current_inst->mode == AM_HL_SPR) {
        u8 hflag = (cpu_read_regis(ctx->current_inst->reg_2) & 0xF) + 
            (ctx->fetch_data & 0xF) >= 0x10;

        u8 cflag = (cpu_read_regis(ctx->current_inst->reg_2) & 0xFF) + 
            (ctx->fetch_data & 0xFF) >= 0x100;

        // Set the flags
        cpu_set_flags(ctx, 0, 0, hflag, cflag);
        cpu_set_reg(ctx->current_inst->reg_1, 
            cpu_read_regis(ctx->current_inst->reg_2) + (int8_t)ctx->fetch_data);

        return;
    }

    // Immediate value
    cpu_set_reg(ctx->current_inst->reg_1, ctx->fetch_data);
}

// Load High
static void proc_ldh(cpu_context *ctx) {
    if (ctx->current_inst->reg_1 == RT_A) {
        cpu_set_reg(ctx->current_inst->reg_1, bus_read(0xFF00 | ctx->fetch_data));
    } else {
        bus_write(ctx->mem_dest, ctx->regis.a);
    }

    emu_cycle(1);
}

// Check Condition
static bool check_cond(cpu_context *ctx) {
    bool z = CPU_FLAG_Z;
    bool c = CPU_FLAG_C;

    // Check if the condition is met
    switch(ctx->current_inst->cond) {
        case CT_NONE:   return true;
        case CT_Z:      return z;
        case CT_NZ:     return !z;
        case CT_C:      return c;
        case CT_NC:     return !c;
    }

    return false;
}

// Jump to certain address in stack
static void jp_to_addr(cpu_context *ctx, u16 addr, bool pushpc) {
    if (check_cond(ctx)) {
        if (pushpc) {
            emu_cycle(2);
            stack_push16(ctx->regis.pc);
        }

        ctx->regis.pc = addr;
        emu_cycle(1);
    }
}

// Jump to address
static void proc_jp(cpu_context *ctx) {
    // Jump to the specified address
    jp_to_addr(ctx, ctx->fetch_data, false);
}

// Jump Relative
static void proc_jr(cpu_context *ctx) {
    int8_t rel = (int8_t)(ctx->fetch_data & 0xFF);
    u16 addr = ctx->regis.pc + rel;
    jp_to_addr(ctx, addr, false);
    // if(check_cond(ctx)) {
    //     u8 offset = ctx->fetch_data; // Get the relative offset
    //     ctx->regis.pc += (char)offset; // Update PC with the relative offset
    //     emu_cycle(1); // Increment cycle for jump
    // }
}

// Reset
static void proc_rst(cpu_context *ctx) {
    jp_to_addr(ctx, ctx->current_inst->param, true);
}

// Return
static void proc_ret(cpu_context *ctx) {
    if (ctx->current_inst->cond != CT_NONE) {
        emu_cycle(1);
    }

    // Check if the condition is met
    if (check_cond(ctx)) {
        u16 lo = stack_pop();
        emu_cycle(1);
        u16 hi = stack_pop();
        emu_cycle(1);

        // Combine the high and low bytes
        // Combine high and low bytes
        // u16 value = lo | (hi << 8); // Combine high and low bytes
        u16 n = (hi << 8) | lo;
        ctx->regis.pc = n;  // Set PC to the popped value
        // Increment cycle for return operation
        emu_cycle(1);
    }
}

// Call
static void proc_call(cpu_context *ctx) {
    jp_to_addr(ctx, ctx->fetch_data, true);
}

// Return instruction
static void proc_reti(cpu_context *ctx) {
    ctx->int_master_enabled = true;
    proc_ret(ctx);
}

// Pop out of the stack
static void proc_pop(cpu_context *ctx) {
    u16 lo = stack_pop();
    emu_cycle(1);
    u16 hi = stack_pop();
    emu_cycle(1);

    // Combine the high and low bytes
    u16 n = (hi << 8) | lo;

    // Set the register
    cpu_set_reg(ctx->current_inst->reg_1, n);

    // If the register is AF, clear the lower nibble
    if (ctx->current_inst->reg_1 == RT_AF) {
        cpu_set_reg(ctx->current_inst->reg_1, n & 0xFFF0);
    }
}

// Push onto the stack
static void proc_push(cpu_context *ctx) {
    u16 hi = (cpu_read_regis(ctx->current_inst->reg_1) >> 8) & 0xFF;
    emu_cycle(1);
    stack_push(hi);

    u16 lo = cpu_read_regis(ctx->current_inst->reg_1) & 0xFF;
    emu_cycle(1);
    stack_push(lo);

    emu_cycle(1);
}

//// Math instructions
// Decrement
static void proc_dec(cpu_context *ctx) {
    u16 val = cpu_read_regis(ctx->current_inst->reg_1) - 1;

    if (is_16_bit(ctx->current_inst->reg_1)) {
        emu_cycle(1);
    }

    if (ctx->current_inst->reg_1 == RT_HL && ctx->current_inst->mode == AM_MR) {
        val = bus_read(cpu_read_regis(RT_HL)) - 1;
        bus_write(cpu_read_regis(RT_HL), val);
    } else {
        cpu_set_reg(ctx->current_inst->reg_1, val);
        val = cpu_read_regis(ctx->current_inst->reg_1);
    }

    if ((ctx->current_opcode & 0x0B) == 0x0B) {
        return;
    }

    cpu_set_flags(ctx, val == 0, 1, (val & 0x0F) == 0x0F, -1);
}

// Increment
static void proc_inc(cpu_context *ctx) {
    u16 val = cpu_read_regis(ctx->current_inst->reg_1) + 1;
    // u8 value = (ctx->fetch_data + 1) & 0xFF; // Increment the fetched data
    // cpu_set_regis(ctx->current_inst->reg_1, value); // Set the first register to the incremented value

    if (is_16_bit(ctx->current_inst->reg_1)) {
        emu_cycle(1);
    }

    if (ctx->current_inst->reg_1 == RT_HL && ctx->current_inst->mode == AM_MR) {
        val = bus_read(cpu_read_regis(RT_HL)) + 1;
        val &= 0xFF;
        bus_write(cpu_read_regis(RT_HL), val);
    } else {
        cpu_set_reg(ctx->current_inst->reg_1, val);
        val = cpu_read_regis(ctx->current_inst->reg_1);
    }

    if ((ctx->current_opcode & 0x03) == 0x03) {
        return;
    }

    cpu_set_flags(ctx, val == 0, 0, (val & 0x0F) == 0, -1);
}

// Subtract
static void proc_sub(cpu_context *ctx) {
    u16 val = cpu_read_regis(ctx->current_inst->reg_1) - ctx->fetch_data;

    // Set the flags
    int flg_z = val == 0;
    int flg_h = ((int)cpu_read_regis(ctx->current_inst->reg_1) & 0xF) - ((int)ctx->fetch_data & 0xF) < 0;
    int flg_c = ((int)cpu_read_regis(ctx->current_inst->reg_1)) - ((int)ctx->fetch_data) < 0;

    // Set the register and flags
    cpu_set_reg(ctx->current_inst->reg_1, val);
    cpu_set_flags(ctx, flg_z, 1, flg_h, flg_c);
}

// Subtraction with Carry
static void proc_sbc(cpu_context *ctx) {
    u8 val = ctx->fetch_data + CPU_FLAG_C;

    // Set the flags
    int flg_z = cpu_read_regis(ctx->current_inst->reg_1) - val == 0;
    int flg_h = ((int)cpu_read_regis(ctx->current_inst->reg_1) & 0xF) 
        - ((int)ctx->fetch_data & 0xF) - ((int)CPU_FLAG_C) < 0;
    int flg_c = ((int)cpu_read_regis(ctx->current_inst->reg_1)) 
        - ((int)ctx->fetch_data) - ((int)CPU_FLAG_C) < 0;

    // Set the register and flags
    cpu_set_reg(ctx->current_inst->reg_1, cpu_read_regis(ctx->current_inst->reg_1) - val);
    cpu_set_flags(ctx, flg_z, 1, flg_h, flg_c);
}

// Addition with Carry
static void proc_adc(cpu_context *ctx) {
    u16 u = ctx->fetch_data;
    u16 a = ctx->regis.a;
    u16 c = CPU_FLAG_C;

    // Update the accumulator in decimal mode
    ctx->regis.a = (a + u + c) & 0xFF;

    // Set the flags
    cpu_set_flags(ctx, ctx->regis.a == 0, 0, 
        (a & 0xF) + (u & 0xF) + c > 0xF,
        a + u + c > 0xFF);
}

// Addition
static void proc_add(cpu_context *ctx) {
    u32 val = cpu_read_regis(ctx->current_inst->reg_1) + ctx->fetch_data;

    // Check if the register is 16-bit
    bool is_16bit = is_16_bit(ctx->current_inst->reg_1);

    // If the register is 16-bit, emulate an additional cycle
    if (is_16bit) {
        emu_cycle(1);
    }

    // Handle stack pointer addition
    if (ctx->current_inst->reg_1 == RT_SP) {
        val = cpu_read_regis(ctx->current_inst->reg_1) + (int8_t)ctx->fetch_data;
    }

    // Set the flags
    int flg_z = (val & 0xFF) == 0;
    int flg_h = (cpu_read_regis(ctx->current_inst->reg_1) & 0xF) + (ctx->fetch_data & 0xF) >= 0x10;
    int flg_c = (int)(cpu_read_regis(ctx->current_inst->reg_1) & 0xFF) + (int)(ctx->fetch_data & 0xFF) >= 0x100;

    if (is_16bit) {
        flg_z = -1;
        flg_h = (cpu_read_regis(ctx->current_inst->reg_1) & 0xFFF) + (ctx->fetch_data & 0xFFF) >= 0x1000;
        u32 n = ((u32)cpu_read_regis(ctx->current_inst->reg_1)) + ((u32)ctx->fetch_data);
        flg_c = n >= 0x10000;
    }

    if (ctx->current_inst->reg_1 == RT_SP) {
        flg_z = 0;
        flg_h = (cpu_read_regis(ctx->current_inst->reg_1) & 0xF) + (ctx->fetch_data & 0xF) >= 0x10;
        flg_c = (int)(cpu_read_regis(ctx->current_inst->reg_1) & 0xFF) + (int)(ctx->fetch_data & 0xFF) >= 0x100;
    }

    // Update the register and flags
    cpu_set_reg(ctx->current_inst->reg_1, val & 0xFFFF);
    cpu_set_flags(ctx, flg_z, 0, flg_h, flg_c);
}

//// Instruction processors
// Reference: https://gbdev.io/pandocs/CPU_Instruction_Set.html
static IN_PROC processors[] = {
    [IN_NONE] = proc_none,  // Invalid instruction
    [IN_NOP] = proc_nop,    // No operation
    [IN_LD] = proc_ld,      // Load instruction
    [IN_LDH] = proc_ldh,    // Load to/from high memory
    [IN_JP] = proc_jp,      // Jump instruction
    [IN_DI] = proc_di,      // Disable interrupts
    // Stack operations
    [IN_POP] = proc_pop,    // Pop from stack
    [IN_PUSH] = proc_push,  // Push to stack
    [IN_JR] = proc_jr,      // Relative jump
    [IN_CALL] = proc_call,  // Call subroutine
    [IN_RET] = proc_ret,    // Return from subroutine
    [IN_RST] = proc_rst,    // Restart
    [IN_DEC] = proc_dec,    // Decrement
    [IN_INC] = proc_inc,    // Increment
    [IN_ADD] = proc_add,    // Addition
    [IN_ADC] = proc_adc,    // Addition with carry
    [IN_SUB] = proc_sub,    // Subtraction
    [IN_SBC] = proc_sbc,    // Subtraction with carry
    [IN_AND] = proc_and,    // Logical AND
    [IN_XOR] = proc_xor,    // Logical XOR
    [IN_OR] = proc_or,      // Logical OR
    [IN_CP] = proc_cp,      // Compare
    [IN_CB] = proc_cb,      // Call back
    [IN_RRCA] = proc_rrca,  // Rotate right accumulator
    [IN_RLCA] = proc_rlca,  // Rotate left accumulator
    [IN_RRA] = proc_rra,    // Rotate right accumulator
    [IN_RLA] = proc_rla,    // Rotate left accumulator
    [IN_STOP] = proc_stop,  // Stop
    [IN_HALT] = proc_halt,  // Halt
    [IN_DAA] = proc_daa,    // Decimal Adjust
    [IN_CPL] = proc_cpl,    // Complement
    [IN_SCF] = proc_scf,    // Set Carry Flag
    [IN_CCF] = proc_ccf,    // Complement Carry Flag
    [IN_EI] = proc_ei,      // Enable Interrupts
    [IN_RETI] = proc_reti   // Return from Interrupt
};

// Get the instruction processor for a specific instruction type
IN_PROC inst_get_processor(in_type type) {
    return processors[type];
}