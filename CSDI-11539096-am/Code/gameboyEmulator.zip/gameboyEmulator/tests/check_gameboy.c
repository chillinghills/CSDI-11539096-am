#include <check.h> // Important: Check framework
#include <stdio.h>
#include <emu.h>
#include <cpu.h>
#include <stdlib.h>

START_TEST(test_NAN) {
    bool b = cpu_step();
    ck_assert_uint_eq(b, false);
} END_TEST // Just check whether the project is working


// Create the test suite
Suite *stack_suite() {
    Suite *s = suite_create("emu");  // test num for emulator
    TCase *tc = tcase_create("core");  // test case

    // Add tests to the test case
    tcase_add_test(tc, test_NAN);
    suite_add_tcase(s, tc);

    return s;
}

int main() {
    Suite *s = stack_suite(); // Create the test suite
    SRunner *sr = srunner_create(s);  // Create a test runner
    srunner_run_all(sr, CK_NORMAL);
    int nf = srunner_ntests_failed(sr);


    // Free the test runner
    srunner_free(sr);

    return nf == 0 ? 0 : -1;
}

